Filled by the build (Godot Web export). Do not delete this folder.
