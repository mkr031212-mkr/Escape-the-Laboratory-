extends Node2D
## Procedural pixel-style laboratory backdrop (variant 0 reception, 1 research, 2 security).

var w: float = 3000.0
var floor_y: float = 560.0
var ceiling_y: float = 80.0
var variant: int = 0
var signs: Array = []   # [x, text]
var mid_floor_y: float = -1.0   # optional second floor (research lab)
var mid_x0: float = 0.0
var mid_x1: float = 0.0


func _draw() -> void:
	var upper := Color("8d9bb0")
	var lower := Color("2f5f9a")
	var accent := Color("3fd8ff")
	var floor_c := Color("46557a")
	if variant == 1:
		upper = Color("4a5c6e")
		lower = Color("2b4a5c")
		accent = Color("55f0e0")
		floor_c = Color("2f4150")
	elif variant == 3:
		upper = Color("2a3a50")
		lower = Color("1e2c40")
		accent = Color("55c8ff")
		floor_c = Color("25324a")
	elif variant == 4:
		upper = Color("1f3a46")
		lower = Color("16303a")
		accent = Color("40e0d0")
		floor_c = Color("1c3440")
	elif variant == 5:
		upper = Color("a9b4c2")
		lower = Color("8a96a6")
		accent = Color("3fd8ff")
		floor_c = Color("b5bfcc")
	elif variant == 2:
		upper = Color("2c2438")
		lower = Color("231c2e")
		accent = Color("ff5a6e")
		floor_c = Color("2a2433")
	var rng := RandomNumberGenerator.new()
	rng.seed = 7 + variant
	draw_rect(Rect2(-300, -500, w + 600, 1800), Color("0a0d1c"))
	var h := floor_y - ceiling_y
	draw_rect(Rect2(0, ceiling_y, w, h), upper)
	draw_rect(Rect2(0, floor_y - 170, w, 170), lower)
	draw_rect(Rect2(0, floor_y - 172, w, 4), lower.lightened(0.35))
	var x := 0.0
	while x < w:
		draw_line(Vector2(x, ceiling_y), Vector2(x, floor_y), Color(0, 0, 0, 0.16), 2.0)
		x += 150.0
	for i in int(w / 90.0):          # grime / stains
		var sx := rng.randf() * w
		draw_rect(Rect2(sx, ceiling_y + 30.0 + rng.randf() * 200.0, 6.0 + rng.randf() * 40.0, 2.0), Color(0, 0, 0, 0.12))
	draw_rect(Rect2(0, ceiling_y, w, 26), Color("171c33"))
	draw_rect(Rect2(0, ceiling_y + 26, w, 3), accent.darkened(0.45))
	if variant != 2:     # pipes along the ceiling
		draw_rect(Rect2(0, ceiling_y + 38, w, 10), Color("5d6a80"))
		draw_rect(Rect2(0, ceiling_y + 38, w, 3), Color("8c9ab4"))
		var px := 260.0
		while px < w:
			draw_rect(Rect2(px, ceiling_y + 38, 10, floor_y - ceiling_y - 120.0 if variant == 1 or variant == 4 else 60.0), Color("5d6a80"))
			px += 520.0
	if variant == 2:                      # monitor wall + red warning strips
		var mx := 60.0
		while mx < w - 100.0:
			for r in 2:
				draw_rect(Rect2(mx, ceiling_y + 70.0 + float(r) * 56.0, 70, 44), Color("0c1a22"))
				draw_rect(Rect2(mx + 4, ceiling_y + 74.0 + float(r) * 56.0, 62, 36), Color(0.1, 0.4, 0.5, 0.5))
			mx += 330.0
		var rx := 140.0
		while rx < w:
			draw_rect(Rect2(rx, ceiling_y + 29, 70, 6), Color(1.0, 0.3, 0.35, 0.7))
			rx += 420.0
	var hx := 0.0
	while hx < w:                         # hazard strip at the floor
		draw_rect(Rect2(hx, floor_y - 10, 24, 8), Color("d9b02a") if int(hx / 24.0) % 2 == 0 else Color("1a1a22"))
		hx += 24.0
	draw_rect(Rect2(0, floor_y, w, 300), floor_c)
	draw_rect(Rect2(0, floor_y, w, 5), accent.darkened(0.2))
	var tx := 0.0
	while tx < w:
		draw_line(Vector2(tx, floor_y), Vector2(tx, floor_y + 300.0), Color(0, 0, 0, 0.25), 2.0)
		tx += 80.0
	for i in 5:
		draw_line(Vector2(0, floor_y + 40.0 * float(i)), Vector2(w, floor_y + 40.0 * float(i)), Color(0, 0, 0, 0.2), 2.0)
	if mid_floor_y > 0.0:                 # second storey slab (visual only)
		draw_rect(Rect2(mid_x0, mid_floor_y, mid_x1 - mid_x0, 14), Color("39445a"))
		draw_rect(Rect2(mid_x0, mid_floor_y, mid_x1 - mid_x0, 3), accent.darkened(0.2))
	for s in signs:
		var sx2: float = s[0]
		var sy: float = s[2] if s.size() > 2 else ceiling_y + 62.0
		draw_rect(Rect2(sx2 - 80, sy - 18, 160, 30), Color("10151f"))
		draw_rect(Rect2(sx2 - 80, sy - 18, 160, 30), accent, false, 2.0)
		draw_string(ThemeDB.fallback_font, Vector2(sx2 - 76, sy + 4), s[1], HORIZONTAL_ALIGNMENT_CENTER, 152, 17, accent.lightened(0.3))
