extends Node
## Global state: inventory, progress, input map.

signal inventory_changed

const SAVE_PATH := "user://escape_lab_save.cfg"

var inventory: Dictionary = {}
var unlocked_level: int = 1
var current_level: int = 1
var touch_enabled: bool = false
var _light_tex: GradientTexture2D = null


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	_add_action("move_left", [KEY_A, KEY_LEFT])
	_add_action("move_right", [KEY_D, KEY_RIGHT])
	_add_action("move_up", [KEY_W, KEY_UP])
	_add_action("move_down", [KEY_S, KEY_DOWN])
	_add_action("jump", [KEY_SPACE])
	_add_action("interact", [KEY_E, KEY_ENTER])
	_add_action("run", [KEY_SHIFT])
	_add_action("flashlight", [KEY_F])
	_add_action("pause", [KEY_ESCAPE, KEY_P])
	touch_enabled = DisplayServer.is_touchscreen_available() or OS.has_feature("mobile")
	var cf := ConfigFile.new()
	if cf.load(SAVE_PATH) == OK:
		unlocked_level = int(cf.get_value("progress", "unlocked", 1))
	unlocked_level = 7   # all levels are always selectable


func _add_action(action: String, keys: Array) -> void:
	if not InputMap.has_action(action):
		InputMap.add_action(action)
	for k in keys:
		var ev := InputEventKey.new()
		ev.physical_keycode = k
		InputMap.action_add_event(action, ev)


func add_item(id: String, label: String) -> void:
	inventory[id] = label
	inventory_changed.emit()


func remove_item(id: String) -> void:
	inventory.erase(id)
	inventory_changed.emit()


func has_item(id: String) -> bool:
	return inventory.has(id)


func mark_complete(n: int) -> void:
	unlocked_level = 7
	var cf := ConfigFile.new()
	cf.set_value("progress", "unlocked", unlocked_level)
	cf.save(SAVE_PATH)


func go_level(n: int) -> void:
	current_level = n
	inventory.clear()
	get_tree().paused = false
	get_tree().change_scene_to_file("res://scenes/level_%d.tscn" % n)


func go_menu() -> void:
	get_tree().paused = false
	get_tree().change_scene_to_file("res://scenes/main_menu.tscn")


func light_texture() -> GradientTexture2D:
	if _light_tex == null:
		var g := Gradient.new()
		g.set_color(0, Color(1, 1, 1, 1))
		g.set_color(1, Color(1, 1, 1, 0))
		_light_tex = GradientTexture2D.new()
		_light_tex.gradient = g
		_light_tex.width = 256
		_light_tex.height = 256
		_light_tex.fill = GradientTexture2D.FILL_RADIAL
		_light_tex.fill_from = Vector2(0.5, 0.5)
		_light_tex.fill_to = Vector2(1.0, 0.5)
	return _light_tex


func panel_style(bg: Color, border: Color = Color("3fd8ff"), radius: int = 14, bw: int = 2) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = bg
	s.border_color = border
	s.set_border_width_all(bw)
	s.set_corner_radius_all(radius)
	s.set_content_margin_all(12)
	s.shadow_color = Color(border.r, border.g, border.b, 0.28)
	s.shadow_size = 8
	return s


func make_theme() -> Theme:
	var th := Theme.new()
	th.default_font_size = 20
	var normal := panel_style(Color(0.05, 0.12, 0.26, 0.96), Color("3fd8ff"), 14, 2)
	normal.content_margin_left = 22
	normal.content_margin_right = 22
	var hover := panel_style(Color(0.08, 0.26, 0.48, 1.0), Color("9ff0ff"), 14, 3)
	hover.content_margin_left = 22
	hover.content_margin_right = 22
	var pressed := panel_style(Color("1fb6e0"), Color.WHITE, 14, 3)
	var disabled := panel_style(Color(0.1, 0.1, 0.14, 0.9), Color("444a5e"), 14, 2)
	disabled.shadow_size = 0
	th.set_stylebox("normal", "Button", normal)
	th.set_stylebox("hover", "Button", hover)
	th.set_stylebox("pressed", "Button", pressed)
	th.set_stylebox("disabled", "Button", disabled)
	th.set_stylebox("focus", "Button", StyleBoxEmpty.new())
	th.set_color("font_color", "Button", Color("e8f6ff"))
	th.set_color("font_hover_color", "Button", Color.WHITE)
	th.set_color("font_pressed_color", "Button", Color("06121f"))
	th.set_color("font_disabled_color", "Button", Color("6b7388"))
	th.set_constant("outline_size", "Button", 0)
	return th
