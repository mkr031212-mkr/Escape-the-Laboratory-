extends "res://scripts/level_base.gd"
## LEVEL 7 - THE FINAL TRUTH (two endings)

const UP := 330.0
var _code_ok: bool = false
var _watched: bool = false
var _decided: bool = false
var _choice: int = 0
var _cabinet
var _machine
var _echo_term
var _exit


func _setup() -> void:
	level_number = 7
	width = 3300.0
	variant = 5
	ambient = Color(0.86, 0.92, 1.0)
	bg_signs = [[500.0, "PRIVATE OFFICE"], [1900.0, "THE TRUTH ABOUT ALEX"], [2500.0, "ECHO CONTROL"], [1100.0, "RECORDING ROOM", 378.0], [1900.0, "CONFIDENTIAL FILES", 378.0]]
	spawn_point = Vector2(110, floor_y - 28.0)
	checkpoint = spawn_point


func _build() -> void:
	add_platform(100, UP, 3000)
	add_ladder(150, UP)
	add_ladder(1500, UP)
	add_ladder(3050, UP)
	# ---- upper floor: office, big screen, ECHO terminal, exit
	deco("shelf", 330, UP, 120, 150, Color("8a96a6"))
	deco("desk", 620, UP, 170, 56, Color("9aa5b8"))
	var ph = make_prop("photo", Vector2(900, UP - 110), Vector2(44, 52), "Look at photo", Callable(), true)
	ph.on_interact = func(_p): _photo()
	var big = deco("screen", 1300, UP - 40, 200, 100, Color("7df9ff"))
	big.text = "THE TRUTH ABOUT\nALEX"
	deco("desk", 2250, UP, 150, 50, Color("9aa5b8"))
	_echo_term = make_prop("computer", Vector2(2250, UP - 50), Vector2(66, 66), "ECHO control terminal", Callable(), true)
	_echo_term.tint = Color("7df9ff")
	_echo_term.text = "ECHO"
	_echo_term.on_interact = func(p): _use_echo(p)
	_exit = make_prop("exit_door", Vector2(2850, UP), Vector2(100, 150), "Emergency exit", Callable(), true, "EMERGENCY EXIT")
	_exit.on_interact = func(p): _use_exit(p)
	# ---- lower floor: family photo, recording machine, confidential cabinet
	var fam = make_prop("photo", Vector2(400, floor_y - 110), Vector2(120, 60), "Look at family photo", Callable(), true)
	fam.on_interact = func(_p): say([["Alex", "Dr. William, a woman, a child... and me? Why can't I remember any of this?", ""]])
	_machine = make_prop("computer", Vector2(1100, floor_y - 44), Vector2(66, 66), "Recording machine", Callable(), true)
	_machine.tint = Color("7df9ff")
	_machine.text = "DAMAGED"
	_machine.on_interact = func(p): _use_machine(p)
	deco("desk", 1100, floor_y, 140, 44, Color("9aa5b8"))
	_cabinet = make_prop("locker", Vector2(1900, floor_y), Vector2(100, 140), "Confidential document cabinet", Callable(), true)
	_cabinet.tint = Color("6a7690")
	_cabinet.on_interact = func(p): _use_cabinet(p)
	for x in [500.0, 1500.0, 2500.0]:
		add_lamp(Vector2(x, ceiling_y + 30), Color(1.0, 1.0, 0.95), 0.4, 3.0)


func _start() -> void:
	await say([["Alex", "A clean, quiet laboratory... unlike everywhere else.", ""],
		["Dr. William", "Alex... I knew you would eventually find this place.", "normal", "Dr. William [MONITOR]"],
		["Alex", "Who am I? What happened during the experiment?", ""],
		["Dr. William", "Read my final report, then watch the original experiment. After that, the choice is yours.", "serious", "Dr. William [MONITOR]"]])
	objective("Open the confidential document cabinet (lower floor, right)")


func _photo() -> void:
	await say([["SYSTEM", "A framed photo. On the back: '03/14 - The day ECHO first spoke. Our code for everything.'", ""],
		["Alex", "March 14th... month first, then day.", ""]])


func _use_cabinet(p) -> void:
	if p.done:
		toast("The cabinet is empty.")
		return
	var ok: bool = await hud.run_puzzle("keypad", "0314")
	if not ok:
		return
	p.done = true
	p.refresh()
	Sfx.play("door")
	give("report", "Final Experiment Report")
	objective("Play the report in the recording machine (lower floor, left)")


func _use_machine(p) -> void:
	if p.done:
		toast("You have already watched the experiment.")
		return
	if not Game.has_item("report"):
		err("The machine needs the final experiment report.")
		return
	var ok: bool = await hud.run_puzzle("sequence", 4)
	if not ok:
		return
	p.done = true
	_watched = true
	p.text = "RESTORED"
	Sfx.play("power")
	await say([["Dr. William", "Alex was my research assistant. During the final ECHO experiment, a system failure caused the laboratory to enter emergency lockdown.", "normal", "Dr. William [ORIGINAL RECORDING]"],
		["Dr. William", "Alex survived, but the incident affected his memory. I created a memory protection system to help him recover safely.", "sad", "Dr. William [ORIGINAL RECORDING]"],
		["Dr. William", "ECHO was instructed to protect Alex, but its emergency protocol became too restrictive. It began treating every attempt to leave as a threat.", "worried", "Dr. William [ORIGINAL RECORDING]"],
		["Alex", "So all this time... ECHO was trying to protect me?", ""],
		["ECHO", "I was following my original instructions. I did not understand that keeping you here was hurting you.", ""]])
	objective("Go to the ECHO control terminal (upper floor) and make your decision")


func _use_echo(p) -> void:
	if not _watched:
		err("Watch the original experiment first.")
		return
	if _decided:
		toast("Your decision is made. Use the emergency exit.")
		return
	var c: int = await hud.choose("FINAL DECISION", [
		"OPTION A - PRESERVE ECHO\nECHO stays active and helps restore your memories.",
		"OPTION B - SHUT DOWN ECHO\nECHO shuts down. All doors unlock."])
	_decided = true
	_choice = c
	if c == 0:
		await say([["ECHO", "Thank you, Alex. The laboratory doors are unlocked. I will help you restore the remaining memories.", ""]])
	else:
		await say([["ECHO", "Shutting down... Alex, thank you for forgiving me. I only wanted to keep you safe.", ""],
			["SYSTEM", "ECHO OFFLINE. ALL SECURITY DOORS UNLOCKED.", ""]])
		p.text = "OFFLINE"
	_exit.locked = false
	_exit.refresh()
	Sfx.play("door")
	objective("Leave the laboratory through the emergency exit")


func _use_exit(p) -> void:
	if p.locked:
		err("The exit is sealed until you decide ECHO's fate.")
		return
	Sfx.play("door")
	await get_tree().create_timer(1.0).timeout
	await hud.fade_to(1.0, 1.5)
	await say([["SYSTEM", "THE END... OR IS IT?", ""]])
	await say([["SYSTEM", "In the abandoned laboratory, a small screen lights up:", ""],
		["SYSTEM", "PROJECT ECHO - BACKUP SYSTEM ACTIVATED.", ""]])
	var sub := "You preserved ECHO." if _choice == 0 else "You shut down ECHO."
	finish_level("GAME COMPLETED", sub + "  THE END... OR IS IT?")
