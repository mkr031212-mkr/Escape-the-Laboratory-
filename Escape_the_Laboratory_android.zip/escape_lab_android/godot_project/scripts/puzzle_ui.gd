extends Control
## Overlay puzzles: "circuit" (rotate tiles), "keypad" (4-digit code), "sequence" (memory lights).

signal finished(success)

const TILE := 100.0
const PAD := 80.0

var _title: Label
var _sub: Label
var _body: VBoxContainer
var _session: int = 0
var _tiles: Array = []
var _board: Control
var _code: String = ""
var _code_target: String = ""
var _code_label: Label
var _seq: Array = []
var _pos: int = 0
var _accept: bool = false
var _seq_btns: Array = []


func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP
	theme = Game.make_theme()
	var dim := ColorRect.new()
	dim.color = Color(0, 0, 0, 0.8)
	add_child(dim)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var cc := CenterContainer.new()
	add_child(cc)
	cc.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var pc := PanelContainer.new()
	pc.add_theme_stylebox_override("panel", Game.panel_style(Color("081226"), Color("3fd8ff"), 18, 3))
	cc.add_child(pc)
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 10)
	pc.add_child(vb)
	_title = Label.new()
	_title.add_theme_font_size_override("font_size", 26)
	_title.add_theme_color_override("font_color", Color("7df9ff"))
	_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vb.add_child(_title)
	_sub = Label.new()
	_sub.add_theme_font_size_override("font_size", 16)
	_sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vb.add_child(_sub)
	_body = VBoxContainer.new()
	_body.alignment = BoxContainer.ALIGNMENT_CENTER
	vb.add_child(_body)
	var close := Button.new()
	close.text = "CLOSE"
	close.custom_minimum_size = Vector2(0, 44)
	close.pressed.connect(func(): finished.emit(false))
	vb.add_child(close)


func open(kind: String, arg = null) -> bool:
	_session += 1
	for c in _body.get_children():
		c.queue_free()
	if kind == "circuit":
		_build_circuit()
	elif kind == "keypad":
		_build_keypad(str(arg))
	else:
		_build_sequence(int(arg) if arg != null else 5)
	var res = await finished
	_session += 1
	return bool(res)


# ------------------------------------------------------------------ circuit
func _build_circuit() -> void:
	_title.text = "ELECTRICAL CONTROL PANEL"
	_sub.text = "Tap tiles to rotate them. Connect the battery (left) to the bulb (right)."
	_tiles = [5, 3, 6, 10, 10, 9, 12, 6, 5]
	_board = Control.new()
	_board.custom_minimum_size = Vector2(3.0 * TILE + 2.0 * PAD, 3.0 * TILE)
	_board.draw.connect(_draw_board)
	_board.gui_input.connect(_board_input)
	_body.add_child(_board)


func _power() -> Array:
	var pw: Array = []
	pw.resize(9)
	pw.fill(false)
	if (_tiles[0] & 8) == 0:
		return pw
	pw[0] = true
	var stack: Array = [0]
	while not stack.is_empty():
		var i: int = stack.pop_back()
		var x := i % 3
		var y := floori(i / 3.0)
		var m: int = _tiles[i]
		if (m & 2) != 0 and x < 2 and not pw[i + 1] and (_tiles[i + 1] & 8) != 0:
			pw[i + 1] = true
			stack.append(i + 1)
		if (m & 4) != 0 and y < 2 and not pw[i + 3] and (_tiles[i + 3] & 1) != 0:
			pw[i + 3] = true
			stack.append(i + 3)
		if (m & 8) != 0 and x > 0 and not pw[i - 1] and (_tiles[i - 1] & 2) != 0:
			pw[i - 1] = true
			stack.append(i - 1)
		if (m & 1) != 0 and y > 0 and not pw[i - 3] and (_tiles[i - 3] & 4) != 0:
			pw[i - 3] = true
			stack.append(i - 3)
	return pw


func _solved() -> bool:
	var pw := _power()
	return pw[8] and (_tiles[8] & 2) != 0


func _draw_board() -> void:
	var pw := _power()
	var b := _board
	for i in 9:
		var o := Vector2(PAD + float(i % 3) * TILE, float(floori(i / 3.0)) * TILE)
		b.draw_rect(Rect2(o + Vector2(3, 3), Vector2(TILE - 6, TILE - 6)), Color("141b33"))
		b.draw_rect(Rect2(o + Vector2(3, 3), Vector2(TILE - 6, TILE - 6)), Color("2c3a66"), false, 2.0)
		var col := Color("3fd8ff") if pw[i] else Color("5a6485")
		var cn := o + Vector2(TILE, TILE) / 2.0
		var m: int = _tiles[i]
		var dirs := [Vector2(0, -1), Vector2(1, 0), Vector2(0, 1), Vector2(-1, 0)]
		for k in 4:
			if (m & (1 << k)) != 0:
				b.draw_line(cn, cn + dirs[k] * (TILE / 2.0 - 3.0), col, 12.0)
		b.draw_circle(cn, 9.0, col)
	var y0 := TILE / 2.0
	b.draw_rect(Rect2(10, y0 - 18, 50, 36), Color("2a8a4a"))
	b.draw_rect(Rect2(60, y0 - 5, PAD - 60, 10), Color("3fd8ff"))
	var y2 := 2.0 * TILE + TILE / 2.0
	var lit := _solved()
	b.draw_circle(Vector2(PAD + 3.0 * TILE + 40.0, y2), 22.0, Color("ffe27a") if lit else Color("3a3a4a"))
	b.draw_rect(Rect2(PAD + 3.0 * TILE, y2 - 5, 18, 10), Color("3fd8ff") if lit else Color("5a6485"))


func _board_input(event: InputEvent) -> void:
	if not (event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT):
		return
	var px: float = event.position.x - PAD
	var py: float = event.position.y
	if px < 0.0 or px >= 3.0 * TILE or py < 0.0 or py >= 3.0 * TILE:
		return
	var idx := int(px / TILE) + int(py / TILE) * 3
	var m: int = _tiles[idx]
	_tiles[idx] = ((m << 1) & 15) | (m >> 3)
	Sfx.play("click")
	_board.queue_redraw()
	if _solved():
		var s := _session
		Sfx.play("power")
		await get_tree().create_timer(0.6).timeout
		if s == _session:
			finished.emit(true)


# ------------------------------------------------------------------ keypad
func _build_keypad(code: String) -> void:
	_title.text = "SECURITY COMPUTER"
	_sub.text = "Enter the 4-digit password."
	_code = ""
	_code_target = code
	_code_label = Label.new()
	_code_label.text = "- - - -"
	_code_label.add_theme_font_size_override("font_size", 40)
	_code_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_body.add_child(_code_label)
	var g := GridContainer.new()
	g.columns = 3
	g.add_theme_constant_override("h_separation", 8)
	g.add_theme_constant_override("v_separation", 8)
	_body.add_child(g)
	for k in ["1", "2", "3", "4", "5", "6", "7", "8", "9", "CLR", "0", "DEL"]:
		var b := Button.new()
		b.text = k
		b.custom_minimum_size = Vector2(90, 56)
		b.add_theme_font_size_override("font_size", 24)
		b.pressed.connect(_key.bind(k))
		g.add_child(b)


func _show_code() -> void:
	var s := ""
	for i in 4:
		s += (_code[i] if i < _code.length() else "-") + " "
	_code_label.text = s.strip_edges()


func _key(k: String) -> void:
	Sfx.play("click")
	if k == "CLR":
		_code = ""
	elif k == "DEL":
		_code = _code.substr(0, maxi(0, _code.length() - 1))
	elif _code.length() < 4:
		_code += k
	_show_code()
	if _code.length() == 4:
		var s := _session
		if _code == _code_target:
			_sub.text = "ACCESS GRANTED"
			Sfx.play("pickup")
			await get_tree().create_timer(0.7).timeout
			if s == _session:
				finished.emit(true)
		else:
			_sub.text = "ACCESS DENIED - try again"
			Sfx.play("error")
			await get_tree().create_timer(0.5).timeout
			if s == _session:
				_code = ""
				_show_code()


# ------------------------------------------------------------------ sequence
func _build_sequence(n: int) -> void:
	_title.text = "ECHO FIREWALL"
	_sub.text = "Watch the pattern, then repeat it."
	_seq.clear()
	for i in n:
		_seq.append(randi() % 4)
	_seq_btns.clear()
	var g := GridContainer.new()
	g.columns = 2
	g.add_theme_constant_override("h_separation", 10)
	g.add_theme_constant_override("v_separation", 10)
	_body.add_child(g)
	for i in 4:
		var b := Button.new()
		b.custom_minimum_size = Vector2(130, 100)
		b.pressed.connect(_seq_press.bind(i))
		_seq_style(b, i, false)
		g.add_child(b)
		_seq_btns.append(b)
	_play_seq()


func _seq_style(b: Button, i: int, lit: bool) -> void:
	var base := [Color("e0384a"), Color("38d070"), Color("3a7bff"), Color("e0b020")][i] as Color
	var st := StyleBoxFlat.new()
	st.bg_color = base if lit else base.darkened(0.6)
	st.set_corner_radius_all(12)
	for n in ["normal", "hover", "pressed", "focus"]:
		b.add_theme_stylebox_override(n, st)


func _flash(i: int) -> void:
	var s := _session
	_seq_style(_seq_btns[i], i, true)
	Sfx.play("tone%d" % i)
	await get_tree().create_timer(0.35).timeout
	if s == _session:
		_seq_style(_seq_btns[i], i, false)


func _play_seq() -> void:
	var s := _session
	_accept = false
	_pos = 0
	await get_tree().create_timer(0.7).timeout
	for i in _seq:
		if s != _session:
			return
		_flash(i)
		await get_tree().create_timer(0.55).timeout
	_accept = true
	_sub.text = "Your turn!"


func _seq_press(i: int) -> void:
	if not _accept:
		return
	_flash(i)
	if i == _seq[_pos]:
		_pos += 1
		if _pos >= _seq.size():
			_accept = false
			_sub.text = "FIREWALL BREACHED"
			var s := _session
			await get_tree().create_timer(0.8).timeout
			if s == _session:
				finished.emit(true)
	else:
		Sfx.play("error")
		_sub.text = "Wrong! Watch again..."
		_play_seq()
