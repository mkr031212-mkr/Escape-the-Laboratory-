extends "res://scripts/level_base.gd"
## LEVEL 5 - THE EXPERIMENT CHAMBER

const UP := 330.0
var _cells_in: int = 0
var _mcs: int = 0
var _powered: bool = false
var _repaired: bool = false
var _chip_in: bool = false
var _gen
var _panel
var _chamber
var _obs_door
var _lift
var _hidden: Array = []


func _setup() -> void:
	level_number = 5
	width = 3400.0
	variant = 4
	ambient = Color(0.18, 0.22, 0.30)
	bg_signs = [[300.0, "MYSTERY DETAILS"], [1050.0, "MAIN EXPERIMENT CHAMBER"], [2600.0, "OBSERVATION ROOM"], [300.0, "POWER CONTROL", 378.0], [1200.0, "EXPERIMENT STORAGE", 378.0], [2650.0, "ECHO PROGRAMMING", 378.0]]
	spawn_point = Vector2(110, floor_y - 28.0)
	checkpoint = spawn_point


func _build() -> void:
	add_platform(100, UP, 3000)
	add_ladder(150, UP)
	add_ladder(1500, UP)
	add_ladder(3050, UP)
	# ---- upper floor
	var pe = deco("screen", 300, UP - 60, 130, 70, Color("7df9ff"))
	pe.text = "PROJECT ECHO"
	deco("desk", 300, UP, 140, 50, Color("5f7088"))
	add_item("cell1", "Power Cell 1", "cell", Vector2(420, UP))
	_chamber = deco("chamber", 1000, UP, 190, 160)
	_panel = make_prop("panel", Vector2(1300, UP), Vector2(120, 100), "Machine control panel", Callable(), true)
	_panel.on_interact = func(p): _use_panel(p)
	var failed = make_prop("screen", Vector2(1700, UP - 40), Vector2(130, 70), "Read screen", Callable(), true)
	failed.tint = Color("ff7070")
	failed.text = "EXPERIMENT\nFAILED"
	failed.on_interact = func(_p): say([["SYSTEM", "EXPERIMENT FAILED.", ""], ["Alex", "The whole machine is wrecked...", ""]])
	deco("desk", 1700, UP, 150, 40, Color("5f7088"))
	add_item("mc2", "Machine Component 2", "comp_blue", Vector2(1850, UP))
	_obs_door = make_prop("door", Vector2(2250, UP), Vector2(80, 130), "Observation room", Callable(), true, "OBSERVATION")
	_obs_door.tint = Color("4a5368")
	_obs_door.on_interact = func(p): _use_obs(p)
	deco("desk", 2650, UP, 220, 56, Color("5f7088"))
	var ph = deco("photo", 2900, UP - 100, 40, 50)
	var it1 = add_item("report", "Dr. William's Report", "file", Vector2(2600, UP - 56))
	var it2 = add_item("chip", "Original ECHO Data Chip", "chip", Vector2(2740, UP - 56))
	for it in [it1, it2]:
		it.visible = false
		it.enabled = false
		_hidden.append(it)
	# ---- lower floor
	var rec = make_prop("computer", Vector2(520, floor_y - 50), Vector2(66, 66), "Play recording device", Callable(), true)
	rec.tint = Color("7df9ff")
	rec.text = "REC"
	rec.done = true
	rec.on_interact = func(_p): _recording_1()
	deco("desk", 520, floor_y, 120, 50, Color("5f7088"))
	_gen = make_prop("generator", Vector2(300, floor_y), Vector2(130, 100), "Main generator", Callable(), true)
	_gen.on_interact = func(p): _use_gen(p)
	deco("shelf", 900, floor_y, 120, 130, Color("46506f"))
	add_item("mc1", "Machine Component 1", "comp_red", Vector2(1050, floor_y))
	var st = make_prop("locker", Vector2(1250, floor_y), Vector2(90, 130), "Open storage cabinet", Callable(), true)
	st.tint = Color("5a6a82")
	st.on_interact = func(p): _storage(p, "cell2", "Power Cell 2", "cell")
	var st2 = make_prop("locker", Vector2(1450, floor_y), Vector2(90, 130), "Open cabinet", Callable(), true)
	st2.tint = Color("5a6a82")
	st2.on_interact = func(p): _storage(p, "mc3", "Machine Component 3", "comp_green")
	add_item("cell3", "Power Cell 3", "cell", Vector2(2250, floor_y))
	var echo = deco("screen", 2650, floor_y - 120, 150, 80, Color("40e0d0"))
	echo.text = "ECHO"
	deco("desk", 2650, floor_y, 150, 44, Color("5f7088"))
	var term = make_prop("computer", Vector2(2650, floor_y - 44), Vector2(66, 66), "ECHO programming terminal", Callable(), true)
	term.tint = Color("7df9ff")
	term.text = "INSERT CHIP"
	term.on_interact = func(p): _use_term(p)
	_lift = make_prop("door", Vector2(3250, floor_y), Vector2(90, 140), "Elevator to ECHO's Core", Callable(), true, "ELEVATOR")
	_lift.tint = Color("5a6378")
	_lift.on_interact = func(p): _use_lift(p)
	for x in [300.0, 1200.0, 2200.0, 3000.0]:
		add_lamp(Vector2(x, ceiling_y + 30), Color(1.0, 0.25, 0.25), 0.5, 2.2, true)


func _start() -> void:
	await say([["Alex", "A huge chamber... broken machines, glass tubes. What is this place?", ""],
		["Alex", "There's an old recording device on that desk.", ""]])
	objective("Play the recording device (lower floor)")


func _recording_1() -> void:
	await say([["Dr. William", "If anyone is watching this recording, the experiment has failed. ECHO has stopped following its original instructions.", "worried", "Dr. William [RECORDING]"],
		["Alex", "Dr. William... What happened here?", ""]])
	if _cells_in == 0:
		objective("Find three power cells (0/3)")


func _on_picked(id: String) -> void:
	if id.begins_with("cell"):
		var n := 0
		for k in ["cell1", "cell2", "cell3"]:
			if Game.has_item(k):
				n += 1
		objective("Bring the power cells to the main generator (%d held, %d installed)" % [n, _cells_in])
	elif id.begins_with("mc"):
		_mcs += 1
		if _mcs < 3:
			objective("Find the missing machine components (%d/3)" % _mcs)
		else:
			objective("Install the components in the machine control panel (upper floor)")
	elif id == "report":
		_recording_2()
	elif id == "chip":
		objective("Insert the ECHO data chip in the programming terminal (lower floor, right)")


func _storage(p, id: String, label: String, icon: String) -> void:
	if p.done:
		toast("Empty.")
		return
	p.done = true
	p.refresh()
	Sfx.play("door")
	give(id, label)
	_on_picked(id)


func _use_gen(p) -> void:
	if p.done:
		toast("The generator is running.")
		return
	for k in ["cell1", "cell2", "cell3"]:
		if Game.has_item(k):
			Game.remove_item(k)
			_cells_in += 1
			Sfx.play("click")
	if _cells_in < 3:
		err("Power cells installed: %d/3" % _cells_in)
		return
	p.done = true
	_powered = true
	p.refresh()
	Sfx.play("power")
	set_ambient(Color(0.65, 0.85, 0.95), 1.5)
	toast("MAIN POWER ONLINE")
	objective("Find the missing machine components (%d/3)" % _mcs)


func _use_panel(p) -> void:
	if not _powered:
		err("The panel has no power.")
		return
	if p.done:
		toast("The machine is repaired.")
		return
	for i in 3:
		var id := "mc%d" % (i + 1)
		if Game.has_item(id):
			Game.remove_item(id)
			p.count = p.count | (1 << i)
			Sfx.play("click")
	p.refresh()
	if p.count != 7:
		err("Components missing. Search the storage and the machine room.")
		return
	var ok: bool = await hud.run_puzzle("sequence", 6)
	if not ok:
		return
	p.done = true
	_repaired = true
	_chamber.done = true
	_chamber.refresh()
	Sfx.play("power")
	toast("EXPERIMENTAL MACHINE REPAIRED")
	_obs_door.locked = false
	_obs_door.refresh()
	objective("Open the observation room (upper floor, right)")


func _use_obs(p) -> void:
	if p.locked:
		err("The observation room is sealed. Repair the machine first.")
		return
	if p.done:
		return
	p.done = true
	p.refresh()
	Sfx.play("door")
	for it in _hidden:
		it.visible = true
		it.enabled = true
	objective("Find Dr. William's report and the original ECHO data chip")


func _recording_2() -> void:
	await say([["Alex", "A photo of me... I was part of this?", ""],
		["Dr. William", "Alex, you were never supposed to forget what happened here. I had to protect you from the truth.", "sad", "Dr. William [RECORDING]"],
		["Alex", "Why did you erase my memories?", ""]])
	set_ambient(Color(0.6, 0.15, 0.15), 0.4)
	Sfx.play("alarm")
	await say([["ECHO", "ACCESS DENIED. EXPERIMENT RECORDING LOCKED.", ""]])
	set_ambient(Color(0.65, 0.85, 0.95), 1.0)
	if Game.has_item("chip"):
		objective("Insert the ECHO data chip in the programming terminal")
	else:
		objective("Recover the original ECHO data chip")


func _use_term(p) -> void:
	if p.done:
		return
	if not Game.has_item("chip"):
		err("The terminal needs the original ECHO data chip.")
		return
	Game.remove_item("chip")
	p.done = true
	_chip_in = true
	p.text = "CHIP OK"
	Sfx.play("power")
	await say([["SYSTEM", "Original ECHO programming loaded...", ""],
		["SYSTEM", "CENTRAL AI LOCATION: LEVEL 6.", ""]])
	_lift.locked = false
	_lift.refresh()
	objective("Take the elevator down to ECHO's Core")


func _use_lift(p) -> void:
	if p.locked:
		err("The elevator is locked.")
		return
	Sfx.play("door")
	finish_level("LEVEL 5 COMPLETED", "The Experiment Chamber")
