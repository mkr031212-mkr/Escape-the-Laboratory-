extends Node
## Procedurally generated sound effects and ambient music (no audio files needed).

const RATE := 22050

var _players: Array = []
var _cache: Dictionary = {}
var _music: AudioStreamPlayer
var _music_stream: AudioStreamWAV


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	for i in 8:
		var p := AudioStreamPlayer.new()
		p.volume_db = -4.0
		add_child(p)
		_players.append(p)
	_music = AudioStreamPlayer.new()
	_music.volume_db = -15.0
	add_child(_music)
	_cache["pickup"] = _make([660.0, 880.0, 1175.0], 0.07, 0.35, "sine")
	_cache["jump"] = _make([280.0, 420.0], 0.06, 0.18, "square")
	_cache["click"] = _make([900.0], 0.04, 0.2, "square")
	_cache["door"] = _make([150.0, 120.0, 95.0], 0.12, 0.3, "saw")
	_cache["error"] = _make([220.0, 160.0], 0.1, 0.25, "square")
	_cache["win"] = _make([523.0, 659.0, 784.0, 1047.0], 0.16, 0.35, "sine")
	_cache["zap"] = _make([1200.0, 800.0, 500.0, 300.0, 200.0], 0.05, 0.25, "saw")
	_cache["power"] = _make([200.0, 300.0, 400.0, 600.0, 800.0], 0.1, 0.3, "saw")
	_cache["alarm"] = _make([880.0, 620.0, 880.0, 620.0], 0.12, 0.25, "square")
	_cache["type"] = _make([1700.0], 0.012, 0.06, "square")
	_cache["step"] = _make([90.0], 0.04, 0.1, "noise")
	_cache["tone0"] = _make([330.0], 0.3, 0.35, "sine")
	_cache["tone1"] = _make([392.0], 0.3, 0.35, "sine")
	_cache["tone2"] = _make([494.0], 0.3, 0.35, "sine")
	_cache["tone3"] = _make([587.0], 0.3, 0.35, "sine")
	_music_stream = _make_music()


func play(sound_name: String, pitch: float = 1.0, vol_db: float = 0.0) -> void:
	if not _cache.has(sound_name):
		return
	for p in _players:
		if not p.playing:
			p.stream = _cache[sound_name]
			p.pitch_scale = pitch
			p.volume_db = vol_db - 4.0
			p.play()
			return


func start_music() -> void:
	if not _music.playing:
		_music.stream = _music_stream
		_music.play()


func _make(notes: Array, note_len: float, vol: float, wave: String) -> AudioStreamWAV:
	var n_per := int(note_len * RATE)
	var total := n_per * notes.size()
	var data := PackedByteArray()
	data.resize(total * 2)
	var phase := 0.0
	for ni in notes.size():
		var f: float = notes[ni]
		for i in n_per:
			var env := pow(1.0 - float(i) / float(n_per), 0.6)
			phase += TAU * f / float(RATE)
			var s := 0.0
			if wave == "square":
				s = 1.0 if sin(phase) > 0.0 else -1.0
			elif wave == "saw":
				s = fmod(phase / TAU, 1.0) * 2.0 - 1.0
			elif wave == "noise":
				s = randf() * 2.0 - 1.0
			else:
				s = sin(phase)
			data.encode_s16((ni * n_per + i) * 2, int(s * env * vol * 32000.0))
	var w := AudioStreamWAV.new()
	w.format = AudioStreamWAV.FORMAT_16_BITS
	w.mix_rate = RATE
	w.stereo = false
	w.data = data
	return w


func _make_music() -> AudioStreamWAV:
	var rate := 11025
	var total := rate * 8
	var data := PackedByteArray()
	data.resize(total * 2)
	var roots := [55.0, 65.5, 49.0, 61.5]
	for i in total:
		var t := float(i) / float(rate)
		var seg := mini(int(t / 2.0), 3)
		var lt := t - float(seg) * 2.0
		var env := sin(PI * lt / 2.0)
		env = env * env
		var f: float = roots[seg]
		var s := sin(TAU * f * t) * 0.5 + sin(TAU * f * 2.0 * t) * 0.18 + sin(TAU * f * 1.5 * t) * 0.12
		s *= env
		var shimmer := sin(TAU * 220.0 * t) * 0.05 * (0.5 + 0.5 * sin(TAU * 0.25 * t))
		var tick := sin(TAU * 110.0 * t) * exp(-fmod(t, 1.0) * 18.0) * 0.12
		var v := (s + shimmer + tick) * 0.6
		data.encode_s16(i * 2, int(clampf(v, -1.0, 1.0) * 30000.0))
	var w := AudioStreamWAV.new()
	w.format = AudioStreamWAV.FORMAT_16_BITS
	w.mix_rate = rate
	w.stereo = false
	w.data = data
	w.loop_mode = AudioStreamWAV.LOOP_FORWARD
	w.loop_begin = 0
	w.loop_end = total
	return w
