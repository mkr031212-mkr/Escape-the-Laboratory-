extends Area2D
## Generic world object: furniture, doors, computers, ladders, collectible items.
## Origin is the bottom-centre of the object. Interactive props show a prompt near the player.

var kind: String = ""
var size: Vector2 = Vector2(40, 40)
var prompt: String = ""
var interactive: bool = true
var enabled: bool = true
var done: bool = false      # opened / used / collected
var locked: bool = true     # doors & readers
var icon: String = ""       # item icon id, or sign text
var count: int = 0          # slots filled (generator, panels)
var tint: Color = Color("56607f")
var text: String = ""       # screen text
var on_interact: Callable = Callable()
var _t: float = 0.0
var _glow: Node2D


func _ready() -> void:
	collision_layer = 8
	collision_mask = 4
	if interactive or kind == "ladder":
		var cs := CollisionShape2D.new()
		var rs := RectangleShape2D.new()
		rs.size = size if kind == "ladder" else Vector2(size.x + 50.0, size.y + 20.0)
		cs.shape = rs
		cs.position = Vector2(0.0, -size.y / 2.0)
		add_child(cs)
		body_entered.connect(_on_enter)
		body_exited.connect(_on_exit)
	else:
		monitoring = false
		monitorable = false
	_glow = Node2D.new()
	var m := CanvasItemMaterial.new()
	m.light_mode = CanvasItemMaterial.LIGHT_MODE_UNSHADED
	_glow.material = m
	add_child(_glow)
	_glow.draw.connect(_draw_glow)


func _on_enter(body: Node) -> void:
	if body.is_in_group("player"):
		if kind == "ladder":
			body.enter_ladder(self)
		else:
			body.add_nearby(self)


func _on_exit(body: Node) -> void:
	if body.is_in_group("player"):
		if kind == "ladder":
			body.exit_ladder(self)
		else:
			body.remove_nearby(self)


func interact() -> void:
	if on_interact.is_valid():
		on_interact.call(self)


func refresh() -> void:
	queue_redraw()
	if _glow:
		_glow.queue_redraw()


func top_y() -> float:
	return global_position.y - size.y


func _process(delta: float) -> void:
	_t += delta
	if _glow:
		_glow.queue_redraw()
	if kind == "generator" and done:
		queue_redraw()


func _r(x: float, y: float, w: float, h: float, c: Color) -> void:
	draw_rect(Rect2(x, y, w, h), c)


# ------------------------------------------------------------------ drawing
func _draw() -> void:
	var w := size.x
	var h := size.y
	match kind:
		"ladder":
			_r(-w / 2.0, -h, 5, h, Color("c79a2b"))
			_r(w / 2.0 - 5.0, -h, 5, h, Color("c79a2b"))
			var y := -h + 8.0
			while y < -4.0:
				_r(-w / 2.0, y, w, 4, Color("e0b23a"))
				y += 16.0
		"crate":
			_r(-w / 2.0, -h, w, h, Color("8a6a43"))
			draw_rect(Rect2(-w / 2.0 + 3, -h + 3, w - 6, h - 6), Color("5d452b"), false, 3.0)
			draw_line(Vector2(-w / 2.0 + 3, -h + 3), Vector2(w / 2.0 - 3, -3), Color("5d452b"), 3.0)
		"desk", "drawer":
			_r(-w / 2.0, -h, w, 9, Color("b98c5e") if kind == "drawer" else tint.lightened(0.3))
			_r(-w / 2.0 + 3, -h + 9, w - 6, h - 9, Color("7a5a3c") if kind == "drawer" else tint)
			if kind == "drawer":
				_r(-w / 2.0 + 8, -h + 16, w - 16, 16, Color("8d6a47"))
				_r(-6, -h + 22, 12, 3, Color("d9d9e6"))
				if done:
					_r(-w / 2.0 + 8, -h + 16, w - 16, 16, Color("2a1d12"))
					_r(-w / 2.0 + 12, -h + 30, w - 24, 8, Color("a67c52"))
				_r(-w / 2.0 + 8, -h + 38, w - 16, 14, Color("8d6a47"))
		"locker":
			_r(-w / 2.0, -h, w, h, tint)
			_r(-w / 2.0, -h, w, 4, tint.lightened(0.3))
			for i in 2:
				var x := -w / 2.0 + 3.0 + float(i) * (w / 2.0)
				_r(x, -h + 8, w / 2.0 - 6.0, h - 14, tint.darkened(0.15))
				for j in 4:
					_r(x + 5, -h + 16 + float(j) * 7.0, w / 2.0 - 16.0, 2, tint.lightened(0.4))
		"cabinet":
			_r(-w / 2.0, -h, w, h, Color("7a4f2e"))
			_r(-w / 2.0 + 3, -h + 4, w / 2.0 - 4.0, h - 8, Color("93633a"))
			_r(1, -h + 4, w / 2.0 - 4.0, h - 8, Color("93633a"))
			_r(-w / 2.0, -h, w, 5, Color("a87646"))
			if not done:
				_r(-5, -h * 0.5, 10, 12, Color("c8c8d0"))
				draw_arc(Vector2(0, -h * 0.5), 5.0, PI, TAU, 8, Color("c8c8d0"), 2.0)
			else:
				_r(-w / 2.0 + 3, -h + 4, w - 6, h - 8, Color("2a1d12"))
		"computer", "screen", "cabinet_pc":
			if kind == "computer":
				_r(-w / 2.0, -26, w, 26, tint)
				_r(-w / 2.0, -26, w, 5, tint.lightened(0.3))
			if kind == "cabinet_pc":
				_r(-w / 2.0, -h, w, h, Color("4a566f"))
				_r(-w / 2.0 + 4, -h + 4, w - 8, 26, Color("14192c"))
				_r(-w / 2.0 + 5, -h + 40, w - 10, h - 46, Color("323c55"))
				_r(-10, -h + 52, 20, 6, Color("222a40") if not done else Color("12331c"))
			else:
				_r(-w / 2.0 + 4, -h, w - 8, h - 26 if kind == "computer" else h, Color("1a2036"))
		"board":
			_r(-w / 2.0 - 4, -h - 4, w + 8, h + 8, Color("7a5a3c"))
			_r(-w / 2.0, -h, w, h, Color("b58b5a"))
			for i in 6:
				var cx := -w / 2.0 + 10.0 + float(i % 3) * (w / 3.0)
				var cy := -h + 8.0 + float(i / 3) * (h / 2.0 - 2.0)
				_r(cx, cy, 18, 22, Color("e8e8dd"))
				_r(cx + 3, cy + 6, 12, 2, Color("777"))
			if not done and icon == "note":
				_r(-18, -h * 0.5 - 14, 36, 28, Color("f5e27a"))
				_r(-14, -h * 0.5 - 6, 28, 2, Color("8a7a2a"))
				_r(-14, -h * 0.5, 22, 2, Color("8a7a2a"))
		"clock":
			draw_circle(Vector2(0, -h / 2.0), h / 2.0, Color("e8e8f0"))
			draw_arc(Vector2(0, -h / 2.0), h / 2.0, 0, TAU, 24, Color("333a55"), 3.0)
			draw_line(Vector2(0, -h / 2.0), Vector2(0, -h * 0.85), Color("222"), 2.0)
			draw_line(Vector2(0, -h / 2.0), Vector2(7, -h * 0.4), Color("222"), 2.0)
		"chair":
			_r(-w / 2.0, -h * 0.45, w, 8, Color("2f58a8"))
			_r(-w / 2.0 + 2, -h, 8, h * 0.55, Color("2f58a8"))
			_r(-2, -h * 0.45, 4, h * 0.4, Color("333"))
			_r(-w / 2.0, -6, w, 4, Color("333"))
		"vent":
			_r(-w / 2.0, -h, w, h, Color("2a3040"))
			for i in 7:
				_r(-w / 2.0 + 6, -h + 8 + float(i) * (h - 16.0) / 7.0, w - 12, 3, Color("12151f"))
		"door", "exit_door":
			var lw := tint if kind == "door" else Color("5a6378")
			_r(-w / 2.0 - 6, -h - 6, w + 12, h + 6, Color("3a4258"))
			_r(-w / 2.0, -h, w, h, lw)
			if kind == "door":
				_r(-w / 2.0 + 10, -h + 18, w - 20, 34, Color("1b2236"))
				if done:
					_r(-w / 2.0, -h, w, h, Color("0b0e1c"))
					_r(-w / 2.0 + 6, -h + 6, w - 12, h - 6, Color("1b3550"))
			_r(w / 2.0 - 14, -h * 0.5, 6, 18, Color("d8d8e0"))
			if icon != "":
				draw_string(ThemeDB.fallback_font, Vector2(-w / 2.0, -h - 14), icon, HORIZONTAL_ALIGNMENT_CENTER, w, 14, Color("cfd6ee"))
			if done:
				_r(-w / 2.0 + 6, -h + 6, w - 12, h - 6, Color("0b0e1c"))
		"doorlock":
			_r(-w / 2.0, -h, w, h, Color("2a3040"))
			_r(-w / 2.0 + 3, -h + 4, w - 6, h * 0.35, Color("0e1a14"))
			for i in 6:
				_r(-w / 2.0 + 4.0 + float(i % 3) * 8.0, -h * 0.5 + float(i / 3) * 8.0, 6, 6, Color("8a93aa"))
		"shelf":
			_r(-w / 2.0, -h, w, h, Color("46506f"))
			for r in 3:
				var sy := -h + 6.0 + float(r) * (h - 10.0) / 3.0
				_r(-w / 2.0 + 3, sy + (h - 10.0) / 3.0 - 6.0, w - 6, 4, Color("8f9bb8"))
				for k in 5:
					var cc: Color = [Color("e0506a"), Color("50c0e0"), Color("a060e0"), Color("60e090"), Color("e0b030")][(k + r) % 5]
					_r(-w / 2.0 + 10.0 + float(k) * (w - 24.0) / 5.0, sy + (h - 10.0) / 3.0 - 22.0, 9, 16, cc)
		"photo":
			_r(-w / 2.0 - 3, -h - 3, w + 6, h + 6, Color("20263a"))
			_r(-w / 2.0, -h, w, h, Color("3b4f78"))
			draw_circle(Vector2(0, -h * 0.58), h * 0.2, Color("d8a67c"))
			_r(-w * 0.28, -h * 0.4, w * 0.56, h * 0.4, Color("e8e8f4"))
		"chamber":
			_r(-w / 2.0, -h, w, h, Color("20466a"))
			_r(-w / 2.0 + 6, -h + 6, w - 12, h - 24, Color("3a8fb5"))
			_r(-w / 2.0, -14, w, 14, Color("46506f"))
			draw_line(Vector2(-18, -30), Vector2(10, -h * 0.55), Color("1d3a55"), 5.0)
		"machine":
			_r(-w / 2.0, -h, w, h, Color("4a526b"))
			_r(-w / 2.0 + 8, -h + 8, w - 16, 28, Color("1a2036"))
			draw_circle(Vector2(-w / 4.0, -h * 0.35), 12.0, Color("2a3040"))
			draw_line(Vector2(-w / 2.0, -h * 0.7), Vector2(-w / 2.0 - 18.0, -h * 0.4), Color("e0b020"), 3.0)
			_r(w / 4.0, -h * 0.5, 14, 40, Color("3a4258"))
		"generator":
			var vx := sin(_t * 60.0) * 0.8 if done else 0.0
			_r(-w / 2.0 + vx, -h * 0.75, w, h * 0.75, Color("46506f"))
			draw_circle(Vector2(-w * 0.28 + vx, -h * 0.4), h * 0.28, Color("38405a"))
			_r(w * 0.1 + vx, -h, w * 0.3, h * 0.25, Color("2d354c"))
			_r(-w / 2.0, -8, w, 8, Color("2a2f44"))
		"panel":
			_r(-w / 2.0, -h, w, h, Color("38405a"))
			_r(-w / 2.0 + 4, -h + 4, w - 8, h - 8, Color("222a40"))
			for i in 3:
				var sx := -w / 2.0 + 10.0 + float(i) * (w - 20.0) / 3.0
				_r(sx, -h + 10, (w - 20.0) / 3.0 - 6.0, 22, Color("101522"))
				if ((count >> i) & 1) == 1:
					var cl: Color = [Color("e0384a"), Color("3a7bff"), Color("38d070")][i]
					_r(sx + 3, -h + 13, (w - 20.0) / 3.0 - 12.0, 16, cl)
			_r(-w / 2.0 + 8, -h + 42, w - 16, 6, Color("8a93aa"))
		"rack":
			_r(-w / 2.0, -h, w, h, Color("26323d"))
			for i in int(h / 12.0) - 1:
				_r(-w / 2.0 + 4, -h + 6.0 + float(i) * 12.0, w - 8, 8, Color("12202a"))
			if locked and kind == "rack":
				pass
		"switch":
			_r(-w / 2.0, -h, w, h, Color("3a4258"))
			_r(-3, -h + 8, 6, h - 16, Color("141824"))
			var ky := -h + 12.0 if done else -h + h - 26.0
			_r(-7, ky, 14, 12, Color("d8d8e0"))
		"sign":
			_r(-w / 2.0, -h, w, h, Color("12161f"))
		"item":
			_draw_item()
		"bookshelf":
			_r(-w / 2.0, -h, w, h, Color("5a3a22"))
			_r(-w / 2.0 + 4, -h + 4, w - 8, h - 8, Color("2e1c10"))
			for r in 4:
				var by := -h + 8.0 + float(r) * (h - 12.0) / 4.0
				_r(-w / 2.0 + 4, by + (h - 12.0) / 4.0 - 4.0, w - 8, 4, Color("7a5230"))
				for k in 6:
					var bc: Color = [Color("8a2a2a"), Color("2a5a8a"), Color("2a7a4a"), Color("8a7a2a"), Color("5a2a7a"), Color("7a7a7a")][(k + r) % 6]
					_r(-w / 2.0 + 8.0 + float(k) * (w - 20.0) / 6.0, by + (h - 12.0) / 4.0 - 24.0, 9, 20, bc)
		"cctv":
			_r(-w / 2.0, -h, w, h, Color("20263a"))
			_r(-w / 2.0 + 4, -h + 4, w - 8, h - 8, Color("0a0e18"))
		_:
			_r(-w / 2.0, -h, w, h, tint)


func _draw_item() -> void:
	var c := Vector2(0, -size.y / 2.0 - 4.0 + sin(_t * 3.0) * 3.0)
	match icon:
		"key":
			var g := Color("d8dcea")
			draw_arc(c + Vector2(-6, 0), 6.0, 0, TAU, 20, g, 3.0)
			draw_line(c, c + Vector2(13, 0), g, 3.0)
			draw_line(c + Vector2(9, 0), c + Vector2(9, 5), g, 3.0)
			draw_line(c + Vector2(13, 0), c + Vector2(13, 5), g, 3.0)
		"card":
			_r(c.x - 12, c.y - 8, 24, 16, Color("2f8fff"))
			_r(c.x - 12, c.y - 3, 24, 4, Color("0d2f66"))
			_r(c.x - 9, c.y + 3, 8, 4, Color("ffd34d"))
		"card_red":
			_r(c.x - 12, c.y - 8, 24, 16, Color("e0384a"))
			_r(c.x - 12, c.y - 3, 24, 4, Color("40101a"))
			_r(c.x - 9, c.y + 3, 8, 4, Color("ffd34d"))
		"note":
			_r(c.x - 9, c.y - 11, 18, 22, Color("f5e27a"))
			_r(c.x - 6, c.y - 5, 12, 2, Color("8a7a2a"))
			_r(c.x - 6, c.y, 9, 2, Color("8a7a2a"))
		"fuse":
			_r(c.x - 4, c.y - 11, 8, 22, Color("dfe8f0"))
			_r(c.x - 5, c.y - 12, 10, 4, Color("b0b0bc"))
			_r(c.x - 5, c.y + 8, 10, 4, Color("b0b0bc"))
			draw_line(c + Vector2(0, -7), c + Vector2(0, 7), Color("ff9030"), 2.0)
		"comp_red", "comp_blue", "comp_green":
			var cl := Color("e0384a")
			if icon == "comp_blue":
				cl = Color("3a7bff")
			elif icon == "comp_green":
				cl = Color("38d070")
			_r(c.x - 10, c.y - 9, 20, 18, cl)
			_r(c.x - 6, c.y - 5, 12, 10, cl.lightened(0.4))
			_r(c.x - 14, c.y - 3, 4, 2, Color("ccc"))
			_r(c.x + 10, c.y - 3, 4, 2, Color("ccc"))
		"file":
			_r(c.x - 12, c.y - 10, 24, 20, Color("d9b06a"))
			_r(c.x - 12, c.y - 12, 12, 4, Color("c49a52"))
			_r(c.x - 7, c.y - 3, 14, 2, Color("7a5a2a"))
			_r(c.x - 7, c.y + 2, 10, 2, Color("7a5a2a"))
		"cell":
			_r(c.x - 8, c.y - 11, 16, 22, Color("2a8a4a"))
			_r(c.x - 4, c.y - 14, 8, 4, Color("c8c8d0"))
			draw_line(c + Vector2(2, -6), c + Vector2(-2, 1), Color("e8ff70"), 2.0)
			draw_line(c + Vector2(-2, 1), c + Vector2(2, 6), Color("e8ff70"), 2.0)
		"chip":
			_r(c.x - 10, c.y - 10, 20, 20, Color("1a2a3a"))
			_r(c.x - 6, c.y - 6, 12, 12, Color("3fd8ff"))
			for q in 4:
				_r(c.x - 13, c.y - 8.0 + float(q) * 5.0, 3, 2, Color("ccc"))
				_r(c.x + 10, c.y - 8.0 + float(q) * 5.0, 3, 2, Color("ccc"))
		"idcard":
			_r(c.x - 12, c.y - 9, 24, 18, Color("e8eef8"))
			_r(c.x - 9, c.y - 6, 8, 9, Color("6a7ca0"))
			_r(c.x + 2, c.y - 5, 8, 2, Color("444"))
			_r(c.x + 2, c.y, 8, 2, Color("444"))
		"book":
			_r(c.x - 11, c.y - 9, 22, 18, Color("6b4326"))
			_r(c.x - 9, c.y - 7, 18, 14, Color("e8e0c8"))
			_r(c.x - 11, c.y - 9, 4, 18, Color("4a2c16"))


func _draw_glow() -> void:
	var w := size.x
	var h := size.y
	var g := _glow
	var ok := Color(0.3, 1.0, 0.5)
	var bad := Color(1.0, 0.25, 0.25)
	match kind:
		"item":
			if not done:
				var r := 20.0 + sin(_t * 4.0) * 3.0
				g.draw_arc(Vector2(0, -h / 2.0 - 4.0), r, 0, TAU, 28, Color(0.3, 0.9, 1.0, 0.7), 2.0)
		"computer", "screen":
			var sh := h - 26.0 if kind == "computer" else h
			var col := tint if done else Color("143a48")
			if kind == "screen":
				col = tint
			g.draw_rect(Rect2(-w / 2.0 + 7.0, -h + 3.0, w - 14.0, sh - 6.0), col)
			if text != "" and (done or kind == "screen"):
				var ly := -h + 18.0
				for ln in text.split("\n"):
					g.draw_string(ThemeDB.fallback_font, Vector2(-w / 2.0 + 10.0, ly), ln, HORIZONTAL_ALIGNMENT_LEFT, w - 18.0, 11, Color(0.05, 0.1, 0.15))
					ly += 14.0
			elif kind == "computer":
				if fmod(_t, 1.0) < 0.5:
					g.draw_rect(Rect2(-w / 2.0 + 12.0, -h + 12.0, 8.0, 3.0), Color("6ff"))
		"cabinet_pc":
			g.draw_rect(Rect2(-w / 2.0 + 6.0, -h + 6.0, w - 12.0, 22.0), Color("1f6f55") if done else Color("5a2030"))
		"door", "exit_door":
			g.draw_circle(Vector2(0, -h + 8.0), 5.0, ok if not locked else bad)
			if not locked:
				g.draw_rect(Rect2(-w / 2.0 + 6.0, -h + 6.0, w - 12.0, h - 6.0), Color(0.1, 0.3, 0.4, 0.5))
		"doorlock":
			g.draw_rect(Rect2(-w / 2.0 + 5.0, -h + 6.0, w - 10.0, h * 0.35 - 4.0), ok if not locked else bad)
		"board":
			if icon == "note" and not done:
				g.draw_arc(Vector2(0, -h / 2.0), 22.0 + sin(_t * 4.0) * 2.0, 0, TAU, 24, Color(0.3, 0.9, 1.0, 0.7), 2.0)
		"panel":
			g.draw_circle(Vector2(w / 2.0 - 10.0, -8.0), 4.0, ok if done else bad)
		"generator":
			g.draw_circle(Vector2(w * 0.3, -h * 0.85), 5.0, ok if done else bad)
		"switch":
			g.draw_circle(Vector2(0, -h - 5.0), 4.0, ok if done else bad)
		"rack":
			for i in 5:
				var on := fmod(_t * 3.0 + float(i) * 1.7, 2.0) < 1.0
				g.draw_rect(Rect2(-w / 2.0 + 8.0, -h + 8.0 + float(i) * 24.0, 4.0, 3.0), Color(0.2, 1, 0.8) if on else Color(0.05, 0.3, 0.3))
		"sign":
			g.draw_rect(Rect2(-w / 2.0 + 4.0, -h + 4.0, w - 8.0, h - 8.0), Color("0b2a1c") if tint.g > 0.5 else Color("1a2a40"))
			var sy := -h / 2.0 - 4.0
			for ln in text.split("\n"):
				g.draw_string(ThemeDB.fallback_font, Vector2(-w / 2.0 + 8.0, sy), ln, HORIZONTAL_ALIGNMENT_CENTER, w - 16.0, 15, tint)
				sy += 18.0
		"cctv":
			if done:
				g.draw_rect(Rect2(-w / 2.0 + 6.0, -h + 6.0, w - 12.0, h - 12.0), Color("0b1a22"))
				g.draw_string(ThemeDB.fallback_font, Vector2(-w / 2.0 + 10.0, -h / 2.0 + 4.0), "NO SIGNAL", HORIZONTAL_ALIGNMENT_LEFT, w - 16.0, 11, Color("6ff"))
			else:
				for i in 8:
					g.draw_rect(Rect2(-w / 2.0 + 6.0 + randf() * (w - 20.0), -h + 6.0 + randf() * (h - 14.0), 8, 3), Color(0.5, 0.9, 1.0, 0.6))
		"chamber":
			if done:
				g.draw_rect(Rect2(-w / 2.0 + 8.0, -h + 8.0, w - 16.0, h - 26.0), Color(0.3, 0.9, 1.0, 0.35))
		"photo", "board_light":
			pass
