extends CanvasLayer
## HUD: objective, inventory, prompts, dialogue with portraits, fades, pause, level-complete.

const TouchScript := preload("res://scripts/touch_controls.gd")
const PuzzleScript := preload("res://scripts/puzzle_ui.gd")

signal advance
signal chosen(idx)

var player = null
var level = null
var dialog_active: bool = false
var _typing: bool = false
var _skip: bool = false
var _last_adv: int = 0
var _toast_tween: Tween = null
var _obj: Label
var _prompt_panel: PanelContainer
var _prompt: Label
var _toast_panel: PanelContainer
var _toast: Label
var _hint: Label
var _inv: HBoxContainer
var _dlg: PanelContainer
var _dlg_name: Label
var _dlg_text: Label
var _dlg_tex: TextureRect
var _echo: Control
var _fade: ColorRect
var _complete: Control
var _c_title: Label
var _c_sub: Label
var _c_next: Button
var _pause: Control
var _puzzle: Control
var _choice: Control
var _choice_box: VBoxContainer


func bind(p, l) -> void:
	player = p
	level = l


func _ready() -> void:
	layer = 10
	process_mode = Node.PROCESS_MODE_ALWAYS
	var ui := Control.new()
	ui.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ui.theme = Game.make_theme()
	add_child(ui)
	ui.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	# objective
	var op := _panel(Color(0.04, 0.07, 0.16, 0.8))
	op.position = Vector2(14, 12)
	_obj = _label("", 18, Color("9fe8ff"))
	op.add_child(_obj)
	ui.add_child(op)
	# top-right: inventory + pause button
	var tr := HBoxContainer.new()
	tr.anchor_left = 1.0
	tr.anchor_right = 1.0
	tr.offset_right = -14.0
	tr.offset_top = 12.0
	tr.grow_horizontal = Control.GROW_DIRECTION_BEGIN
	tr.add_theme_constant_override("separation", 8)
	ui.add_child(tr)
	_inv = HBoxContainer.new()
	_inv.add_theme_constant_override("separation", 6)
	tr.add_child(_inv)
	var pb := Button.new()
	pb.text = " II "
	pb.add_theme_font_size_override("font_size", 22)
	pb.pressed.connect(_toggle_pause)
	pb.focus_mode = Control.FOCUS_NONE
	tr.add_child(pb)
	# hint (tutorial)
	_hint = _label("", 22, Color("ffe27a"))
	_hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_hint.anchor_left = 0.0
	_hint.anchor_right = 1.0
	_hint.offset_top = 70.0
	_hint.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ui.add_child(_hint)
	# toast
	_toast_panel = _panel(Color(0.02, 0.1, 0.2, 0.92))
	_toast_panel.anchor_left = 0.5
	_toast_panel.anchor_right = 0.5
	_toast_panel.offset_top = 108.0
	_toast_panel.grow_horizontal = Control.GROW_DIRECTION_BOTH
	_toast_panel.visible = false
	_toast = _label("", 20, Color.WHITE)
	_toast_panel.add_child(_toast)
	ui.add_child(_toast_panel)
	# interaction prompt
	_prompt_panel = _panel(Color(0.02, 0.1, 0.2, 0.9))
	_prompt_panel.anchor_left = 0.5
	_prompt_panel.anchor_right = 0.5
	_prompt_panel.anchor_top = 1.0
	_prompt_panel.anchor_bottom = 1.0
	_prompt_panel.offset_top = -60.0
	_prompt_panel.grow_horizontal = Control.GROW_DIRECTION_BOTH
	_prompt_panel.grow_vertical = Control.GROW_DIRECTION_BEGIN
	_prompt_panel.visible = false
	_prompt = _label("", 20, Color("7df9ff"))
	_prompt_panel.add_child(_prompt)
	ui.add_child(_prompt_panel)
	# touch controls
	var tc := TouchScript.new()
	tc.hud = self
	ui.add_child(tc)
	# dialogue
	_dlg = _panel(Color(0.02, 0.05, 0.13, 0.96))
	_dlg.anchor_left = 0.5
	_dlg.anchor_right = 0.5
	_dlg.offset_top = 64.0
	_dlg.grow_horizontal = Control.GROW_DIRECTION_BOTH
	_dlg.visible = false
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 14)
	_dlg.add_child(row)
	var frame := PanelContainer.new()
	frame.add_theme_stylebox_override("panel", Game.panel_style(Color("0a1a3a"), Color("3fd8ff"), 16, 3))
	row.add_child(frame)
	var slot := Control.new()
	slot.custom_minimum_size = Vector2(170, 170)
	frame.add_child(slot)
	_dlg_tex = TextureRect.new()
	_dlg_tex.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	_dlg_tex.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	slot.add_child(_dlg_tex)
	_dlg_tex.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_echo = Control.new()
	slot.add_child(_echo)
	_echo.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_echo.draw.connect(_draw_echo)
	var col := VBoxContainer.new()
	col.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_child(col)
	_dlg_name = _label("", 20, Color("7df9ff"))
	col.add_child(_dlg_name)
	_dlg_text = _label("", 22, Color.WHITE)
	_dlg_text.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_dlg_text.custom_minimum_size = Vector2(620, 100)
	col.add_child(_dlg_text)
	var tap := _label("tap / E to continue", 13, Color(0.6, 0.7, 0.8))
	tap.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	col.add_child(tap)
	ui.add_child(_dlg)
	# puzzles
	_puzzle = PuzzleScript.new()
	_puzzle.visible = false
	ui.add_child(_puzzle)
	# fade
	_fade = ColorRect.new()
	_fade.color = Color(0, 0, 0, 0)
	_fade.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ui.add_child(_fade)
	_fade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_choice = ColorRect.new()
	(_choice as ColorRect).color = Color(0, 0, 0, 0.82)
	_choice.visible = false
	ui.add_child(_choice)
	_choice.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var chc := CenterContainer.new()
	_choice.add_child(chc)
	chc.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_choice_box = VBoxContainer.new()
	_choice_box.add_theme_constant_override("separation", 14)
	chc.add_child(_choice_box)
	_build_complete(ui)
	_build_pause(ui)
	Game.inventory_changed.connect(_refresh_inventory)
	_refresh_inventory()


func _panel(bg: Color) -> PanelContainer:
	var pc := PanelContainer.new()
	pc.add_theme_stylebox_override("panel", Game.panel_style(bg, Color("3fd8ff"), 14, 2))
	pc.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return pc


func _label(t: String, sz: int, c: Color) -> Label:
	var l := Label.new()
	l.text = t
	l.add_theme_font_size_override("font_size", sz)
	l.add_theme_color_override("font_color", c)
	l.add_theme_color_override("font_outline_color", Color(0.02, 0.04, 0.1, 0.95))
	l.add_theme_constant_override("outline_size", 5)
	return l


func _btn(t: String, cb: Callable) -> Button:
	var b := Button.new()
	b.text = t
	b.custom_minimum_size = Vector2(300, 56)
	b.add_theme_font_size_override("font_size", 24)
	b.pressed.connect(cb)
	return b


func _build_complete(ui: Control) -> void:
	_complete = ColorRect.new()
	(_complete as ColorRect).color = Color(0.02, 0.04, 0.1, 0.96)
	_complete.visible = false
	ui.add_child(_complete)
	_complete.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var cc := CenterContainer.new()
	_complete.add_child(cc)
	cc.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 14)
	cc.add_child(vb)
	_c_title = _label("", 46, Color("ffe27a"))
	_c_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vb.add_child(_c_title)
	_c_sub = _label("", 24, Color("9fe8ff"))
	_c_sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vb.add_child(_c_sub)
	_c_next = _btn("NEXT LEVEL", func(): Game.go_level(Game.current_level + 1))
	vb.add_child(_c_next)
	vb.add_child(_btn("REPLAY LEVEL", func(): Game.go_level(Game.current_level)))
	vb.add_child(_btn("MAIN MENU", func(): Game.go_menu()))


func _build_pause(ui: Control) -> void:
	_pause = ColorRect.new()
	(_pause as ColorRect).color = Color(0, 0, 0, 0.8)
	_pause.visible = false
	_pause.process_mode = Node.PROCESS_MODE_ALWAYS
	ui.add_child(_pause)
	_pause.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var cc := CenterContainer.new()
	_pause.add_child(cc)
	cc.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 12)
	cc.add_child(vb)
	var t := _label("PAUSED", 40, Color.WHITE)
	t.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vb.add_child(t)
	vb.add_child(_btn("RESUME", _toggle_pause))
	vb.add_child(_btn("RESTART LEVEL", func(): Game.go_level(Game.current_level)))
	vb.add_child(_btn("SOUND ON / OFF", func(): AudioServer.set_bus_mute(0, not AudioServer.is_bus_mute(0))))
	vb.add_child(_btn("TOUCH CONTROLS ON / OFF", func(): Game.touch_enabled = not Game.touch_enabled))
	vb.add_child(_btn("MAIN MENU", func(): Game.go_menu()))


func _toggle_pause() -> void:
	if _complete.visible:
		return
	get_tree().paused = not get_tree().paused
	_pause.visible = get_tree().paused


func _refresh_inventory() -> void:
	for c in _inv.get_children():
		c.queue_free()
	for id in Game.inventory.keys():
		var p := _panel(Color(0.2, 0.15, 0.02, 0.9))
		p.add_child(_label(Game.inventory[id], 16, Color("ffe27a")))
		_inv.add_child(p)


# ------------------------------------------------------------------ public API
func toast(text: String, dur: float = 2.6) -> void:
	_toast.text = text
	_toast_panel.visible = true
	_toast_panel.modulate.a = 1.0
	if _toast_tween != null:
		_toast_tween.kill()
	_toast_tween = create_tween()
	_toast_tween.tween_interval(dur)
	_toast_tween.tween_property(_toast_panel, "modulate:a", 0.0, 0.5)


func set_objective(text: String) -> void:
	_obj.text = "OBJECTIVE: " + text


func set_hint(text: String) -> void:
	_hint.text = text


func lock_player(v: bool) -> void:
	if player != null:
		player.control_enabled = not v


func fade_to(a: float, dur: float = 0.4) -> void:
	var tw := create_tween()
	tw.tween_property(_fade, "color:a", a, dur)
	await tw.finished


func say_lines(lines: Array) -> void:
	dialog_active = true
	lock_player(true)
	for ln in lines:
		await _show_line(ln)
	_dlg.visible = false
	await get_tree().create_timer(0.2).timeout
	dialog_active = false
	lock_player(false)


func _show_line(ln: Array) -> void:
	var who: String = ln[0]
	var face: String = ln[2] if ln.size() > 2 and ln[2] != "" else "normal"
	_dlg_name.text = ln[3] if ln.size() > 3 else who
	var col := Color("7df9ff")
	_dlg_tex.texture = null
	_echo.visible = false
	if who == "Dr. William":
		_dlg_tex.texture = load("res://assets/portraits/william_%s.png" % face)
		col = Color("8fb8ff")
	elif who == "Alex":
		_dlg_tex.texture = load("res://assets/portraits/alex_face.png")
		col = Color("ffd37a")
	elif who == "ECHO":
		_echo.visible = true
		col = Color("c77bff")
	_dlg_name.add_theme_color_override("font_color", col)
	var text: String = ln[1]
	_dlg_text.text = text
	_dlg_text.visible_characters = 0
	_dlg.visible = true
	_typing = true
	_skip = false
	var i := 0
	while i < text.length() and not _skip:
		i += 1
		_dlg_text.visible_characters = i
		if i % 3 == 0:
			Sfx.play("type")
		await get_tree().create_timer(0.025).timeout
	_dlg_text.visible_characters = -1
	_typing = false
	await advance


func _draw_echo() -> void:
	var c := _echo.size / 2.0
	var t := Time.get_ticks_msec() / 1000.0
	for i in 3:
		_echo.draw_arc(c, 20.0 + float(i) * 14.0 + sin(t * 3.0 + float(i)) * 3.0, 0, TAU, 32, Color(0.78, 0.48, 1.0, 0.8 - 0.2 * float(i)), 3.0)
	_echo.draw_circle(c, 9.0 + sin(t * 5.0) * 2.0, Color(0.9, 0.7, 1.0))


func _advance() -> void:
	var now := Time.get_ticks_msec()
	if now - _last_adv < 180:
		return
	_last_adv = now
	if _typing:
		_skip = true
	else:
		advance.emit()


func _input(event: InputEvent) -> void:
	if dialog_active:
		var adv := false
		if event is InputEventScreenTouch and event.pressed:
			adv = true
		elif event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
			adv = true
		elif event.is_action_pressed("interact") or event.is_action_pressed("jump"):
			adv = true
		if adv:
			_advance()
			get_viewport().set_input_as_handled()
	elif event.is_action_pressed("pause"):
		_toggle_pause()


func run_puzzle(kind: String, arg = null) -> bool:
	lock_player(true)
	_puzzle.visible = true
	var ok = await _puzzle.open(kind, arg)
	_puzzle.visible = false
	await get_tree().create_timer(0.25).timeout
	lock_player(false)
	return bool(ok)


func choose(title: String, opts: Array) -> int:
	lock_player(true)
	for c in _choice_box.get_children():
		c.queue_free()
	var t := _label(title, 34, Color("ffe27a"))
	t.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_choice_box.add_child(t)
	for i in opts.size():
		var b := Button.new()
		b.text = opts[i]
		b.custom_minimum_size = Vector2(620, 84)
		b.add_theme_font_size_override("font_size", 22)
		b.pressed.connect(_on_choice.bind(i))
		_choice_box.add_child(b)
	_choice.visible = true
	var r = await chosen
	_choice.visible = false
	return int(r)


func _on_choice(i: int) -> void:
	Sfx.play("click")
	chosen.emit(i)


func show_complete(title: String, sub: String, lvl: int) -> void:
	await fade_to(1.0, 0.8)
	_c_title.text = title
	_c_sub.text = sub
	_c_next.visible = lvl < 7
	_complete.visible = true


func _process(_d: float) -> void:
	if _echo != null and _echo.visible:
		_echo.queue_redraw()
	if player == null or not is_instance_valid(player):
		return
	var tgt = player.current_target()
	if tgt != null and tgt.prompt != "" and not dialog_active and player.control_enabled:
		_prompt_panel.visible = true
		_prompt.text = ("USE: " if Game.touch_enabled else "[E] ") + tgt.prompt
	else:
		_prompt_panel.visible = false
