extends "res://scripts/level_base.gd"
## LEVEL 3 - THE SECURITY ROOM (control room, server room, backup power, final exit).

const PASSWORD := "0314"
var _computer
var _cctv
var _sec_cab
var _server_cab
var _gen
var _switch
var _terminal
var _exit
var _sign
var _unlocked: bool = false
var _fuse_in: bool = false
var _powered: bool = false
var _hint_shown: bool = false


func _setup() -> void:
	level_number = 3
	width = 4300.0
	variant = 2
	ambient = Color(0.30, 0.24, 0.34)
	bg_signs = [[500.0, "AREA 1 - CONTROL"], [1500.0, "AREA 2 - SERVERS"], [2500.0, "AREA 3 - BACKUP POWER"], [3500.0, "AREA 4 - FINAL EXIT"]]
	spawn_point = Vector2(110, floor_y - 28.0)
	checkpoint = spawn_point


func _build() -> void:
	# ---- AREA 1: security control room
	var dr = make_prop("drawer", Vector2(260, floor_y), Vector2(110, 70), "Search desk drawer", Callable(), true)
	dr.on_interact = func(p): _desk_drawer(p)
	deco("desk", 420, floor_y, 100, 50, Color("4a3a58"))
	_computer = make_prop("computer", Vector2(600, floor_y - 54), Vector2(70, 66), "Security computer", Callable(), true)
	_computer.tint = Color("7df9ff")
	_computer.text = "ACCESS OK"
	deco("desk", 600, floor_y, 190, 54, Color("4a3a58"))
	_computer.on_interact = func(p): _use_computer(p)
	var echo = deco("screen", 520, floor_y - 160, 140, 80, Color("c77bff"))
	echo.text = "ECHO AI"
	_cctv = make_prop("cctv", Vector2(800, floor_y - 120), Vector2(100, 60), "CCTV control panel", Callable(), true)
	_cctv.on_interact = func(p): _use_cctv(p)
	deco("desk", 800, floor_y, 100, 54, Color("4a3a58"))
	_sec_cab = make_prop("locker", Vector2(940, floor_y), Vector2(90, 130), "Security cabinet", Callable(), true)
	_sec_cab.tint = Color("5a5470")
	_sec_cab.on_interact = func(p): _use_sec_cab(p)
	# ---- AREA 2: server room with cameras
	for x in [1150.0, 1260.0, 1400.0, 1640.0, 1760.0]:
		deco("rack", x, floor_y, 70, 150, Color("26323d"))
	add_crate(1110, floor_y)
	add_crate(1330, floor_y)
	add_crate(1550, floor_y)
	add_crate(1790, floor_y)
	add_camera(Vector2(1330, 190), 110.0)
	add_camera(Vector2(1790, 190), 110.0, 50.0, 130.0, 360.0, 1.1)
	_server_cab = make_prop("rack", Vector2(1950, floor_y), Vector2(90, 150), "Server cabinet", Callable(), true)
	_server_cab.on_interact = func(p): _use_server_cab(p)
	# ---- AREA 3: backup power
	_gen = make_prop("generator", Vector2(2500, floor_y), Vector2(170, 110), "Backup generator", Callable(), true)
	_gen.on_interact = func(p): _use_gen(p)
	_switch = make_prop("switch", Vector2(2800, floor_y - 40), Vector2(36, 60), "Emergency power switch", Callable(), true)
	_switch.on_interact = func(p): _use_switch(p)
	deco("locker", 2250, floor_y, 90, 120, Color("6a4050"))
	# ---- AREA 4: final exit
	_terminal = make_prop("screen", Vector2(3450, floor_y - 40), Vector2(150, 90), "ECHO AI terminal", Callable(), true)
	_terminal.tint = Color("c77bff")
	_terminal.text = "ECHO AI\nNO POWER"
	deco("desk", 3450, floor_y, 170, 40, Color("4a3a58"))
	_terminal.on_interact = func(p): _use_terminal(p)
	_exit = make_prop("exit_door", Vector2(4050, floor_y), Vector2(100, 150), "Final exit", Callable(), true, "EXIT")
	_exit.on_interact = func(p): _use_exit(p)
	_sign = make_prop("sign", Vector2(3830, floor_y - 160), Vector2(190, 70), "", Callable(), false)
	_sign.tint = Color("6dffb0")
	for x in [200.0, 800.0, 1400.0, 2000.0, 2600.0, 3200.0]:
		add_lamp(Vector2(x, ceiling_y + 30), Color(1.0, 0.2, 0.25), 0.6, 2.6, true)


func _start() -> void:
	objective("Search the security control room")
	await say([["ECHO", "Security clearance accepted. Welcome to the restricted section, Alex.", ""],
		["Alex", "That voice... the lab AI. It knows my name.", ""],
		["ECHO", "This section is under lockdown. Please remain where you are.", ""],
		["Alex", "Not a chance.", ""]])


func _process(delta: float) -> void:
	super(delta)
	if player == null:
		return
	var x: float = player.global_position.x
	if player.global_position.y > floor_y - 60.0:
		if x > 2000.0:
			checkpoint = Vector2(2000, floor_y - 28.0)
		elif x > 1000.0:
			checkpoint = Vector2(1000, floor_y - 28.0)
	if not _hint_shown and x > 1000.0 and not _unlocked:
		_hint_shown = true
		toast("Security cameras! Hold DOWN (crouch) beside a crate to hide.")


func _desk_drawer(p) -> void:
	if p.done:
		toast("Clue: ECHO first spoke on 03/14.")
		return
	p.done = true
	p.refresh()
	Sfx.play("door")
	give("clue", "Password Clue")
	await say([["SYSTEM", "A note in dr. William's handwriting: 'ECHO's first words were on March 14th. I use that date for everything: month, then day.'", ""],
		["Alex", "Month, then day... March is 03. So the code should be four digits.", ""]])
	objective("Unlock the security computer")


func _use_computer(p) -> void:
	if p.done:
		toast("The security computer is unlocked.")
		return
	if not Game.has_item("clue"):
		err("PASSWORD REQUIRED. Search the desk for a clue.")
		return
	var ok: bool = await hud.run_puzzle("keypad", PASSWORD)
	if not ok:
		return
	p.done = true
	_unlocked = true
	p.refresh()
	Sfx.play("power")
	toast("SECURITY COMPUTER UNLOCKED")
	objective("Open the security cabinet; the CCTV panel can switch off the cameras")


func _use_cctv(p) -> void:
	if not _unlocked:
		err("CCTV control is locked. Unlock the security computer first.")
		return
	if p.done:
		toast("Cameras are already offline.")
		return
	p.done = true
	p.refresh()
	for c in cams:
		c.active = false
	Sfx.play("zap")
	toast("SECURITY CAMERAS DISABLED")


func _use_sec_cab(p) -> void:
	if p.done:
		toast("Empty.")
		return
	if not _unlocked:
		err("Locked. The security computer controls this cabinet.")
		return
	p.done = true
	p.refresh()
	Sfx.play("door")
	give("server_key", "Server Room Key")
	objective("Go to the server room and open the server cabinet")


func _use_server_cab(p) -> void:
	if p.done:
		toast("Empty.")
		return
	if not Game.has_item("server_key"):
		err("LOCKED - server room key required")
		return
	p.done = true
	p.refresh()
	Game.remove_item("server_key")
	Sfx.play("door")
	give("fuse", "Backup Power Fuse")
	objective("Install the fuse in the backup generator")


func _use_gen(p) -> void:
	if _fuse_in:
		toast("Fuse installed. Flip the emergency power switch.")
	elif not Game.has_item("fuse"):
		err("The fuse slot is empty. Find a fuse.")
	else:
		_fuse_in = true
		Game.remove_item("fuse")
		p.count = 1
		Sfx.play("power")
		toast("Fuse installed")
		objective("Flip the emergency power switch")


func _use_switch(p) -> void:
	if not _fuse_in:
		err("No power. The generator needs a fuse.")
		return
	if p.done:
		return
	p.done = true
	_powered = true
	_gen.done = true
	_gen.refresh()
	p.refresh()
	Sfx.play("power")
	set_ambient(Color(0.75, 0.9, 0.95), 1.5)
	for x in [2300.0, 2900.0, 3500.0, 4000.0]:
		add_lamp(Vector2(x, ceiling_y + 30), Color(0.5, 1.0, 0.8), 0.8, 3.0)
	_terminal.text = "ECHO AI\nONLINE"
	toast("BACKUP POWER ONLINE")
	objective("Use the ECHO AI terminal at the final exit")


func _use_terminal(p) -> void:
	if not _powered:
		err("The terminal has no power.")
		return
	if p.done:
		toast("The terminal is dead.")
		return
	await say([["ECHO", "Hello, Alex. I have been waiting. Solve my firewall if you wish to leave.", ""]])
	var ok: bool = await hud.run_puzzle("sequence", 5)
	if not ok:
		return
	p.done = true
	await say([["ECHO", "Impossible... Alex, you are making a mistake. Stop.", ""],
		["Dr. William", "Alex, I knew you would find this place.", "happy", "Dr. William [FINAL RECORDING]"],
		["Dr. William", "There is something you need to know about ECHO...", "serious", "Dr. William [FINAL RECORDING]"]])
	Sfx.play("zap")
	_terminal.text = "SYSTEM\nOFFLINE"
	toast("THE COMPUTER SHUTS DOWN")
	await get_tree().create_timer(0.8).timeout
	give("exit_card", "Final Exit Access Card")
	objective("Use the final exit access card on the exit door")


func _use_exit(p) -> void:
	if p.done:
		return
	if not Game.has_item("exit_card"):
		err("ACCESS DENIED - final exit card required")
		return
	p.done = true
	p.locked = false
	p.refresh()
	Sfx.play("door")
	_sign.text = "THE TRUTH IS\nSTILL HIDDEN..."
	toast("FINAL EXIT UNLOCKED")
	await get_tree().create_timer(2.0).timeout
	await hud.fade_to(1.0, 1.0)
	await say([["ECHO", "Security section breached... Alex, there is nothing good beyond this door.", ""]])
	finish_level("LEVEL 3 COMPLETED", "The Security Room")
