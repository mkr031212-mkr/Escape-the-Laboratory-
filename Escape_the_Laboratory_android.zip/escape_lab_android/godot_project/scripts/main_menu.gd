extends Control
## Title screen, level select and how-to-play.

var _t: float = 0.0
var _main: VBoxContainer
var _levels: VBoxContainer
var _how: Control
var _hero: TextureRect


func _ready() -> void:
	theme = Game.make_theme()
	Sfx.start_music()
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	# hero (Alex) on the right, floating on a glowing pad
	_hero = TextureRect.new()
	_hero.texture = load("res://assets/sprites/alex_idle.png")
	_hero.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	_hero.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	_hero.anchor_left = 1.0
	_hero.anchor_right = 1.0
	_hero.anchor_top = 0.5
	_hero.anchor_bottom = 0.5
	_hero.offset_left = -430.0
	_hero.offset_right = -90.0
	_hero.offset_top = -270.0
	_hero.offset_bottom = 230.0
	add_child(_hero)
	# title + menus (left)
	var left := VBoxContainer.new()
	left.position = Vector2(70, 50)
	left.add_theme_constant_override("separation", 10)
	add_child(left)
	left.add_child(_lbl("ESCAPE THE", 54, Color("eaf6ff")))
	left.add_child(_lbl("LABORATORY", 68, Color("3fd8ff")))
	left.add_child(_lbl("2D puzzle  /  adventure  /  mystery", 20, Color("9aa8c8")))
	var sp := Control.new()
	sp.custom_minimum_size = Vector2(0, 20)
	left.add_child(sp)
	_main = VBoxContainer.new()
	_main.add_theme_constant_override("separation", 12)
	left.add_child(_main)
	_main.add_child(_btn("START GAME", func(): Game.go_level(1)))
	_main.add_child(_btn("LEVEL SELECT", func(): _show(_levels)))
	_main.add_child(_btn("HOW TO PLAY", func(): _show(_how)))
	if not OS.has_feature("mobile") and not OS.has_feature("web"):
		_main.add_child(_btn("QUIT", func(): get_tree().quit()))
	_levels = VBoxContainer.new()
	_levels.visible = false
	_levels.add_theme_constant_override("separation", 10)
	left.add_child(_levels)
	var names := ["1  THE AWAKENING", "2  RESEARCH LAB", "3  SECURITY ROOM", "4  FORGOTTEN ARCHIVE", "5  EXPERIMENT CHAMBER", "6  ECHO'S CORE", "7  THE FINAL TRUTH"]
	var grid := GridContainer.new()
	grid.columns = 2
	grid.add_theme_constant_override("h_separation", 10)
	grid.add_theme_constant_override("v_separation", 8)
	_levels.add_child(grid)
	for i in 7:
		var ok: bool = Game.unlocked_level >= i + 1
		var b := _btn("LEVEL " + names[i] if ok else "LEVEL %d - LOCKED" % (i + 1), func(): Game.go_level(i + 1))
		b.disabled = not ok
		b.add_theme_font_size_override("font_size", 16)
		b.custom_minimum_size = Vector2(330, 54)
		grid.add_child(b)
	_levels.add_child(_btn("BACK", func(): _show(_main)))
	_build_how()


func _build_how() -> void:
	_how = ColorRect.new()
	(_how as ColorRect).color = Color(0.02, 0.04, 0.1, 0.97)
	_how.visible = false
	add_child(_how)
	_how.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var cc := CenterContainer.new()
	_how.add_child(cc)
	cc.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 14)
	cc.add_child(vb)
	var title := _lbl("HOW TO PLAY", 40, Color("3fd8ff"))
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vb.add_child(title)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 22)
	row.alignment = BoxContainer.ALIGNMENT_CENTER
	vb.add_child(row)
	var caps := {"idle": "Stand", "run": "Run  (Shift)", "jump": "Jump  (Space)", "interact": "Use  (E)", "crouch": "Crouch  (S)", "climb": "Climb  (W / S)"}
	for k in caps.keys():
		var col := VBoxContainer.new()
		row.add_child(col)
		var tr := TextureRect.new()
		tr.texture = load("res://assets/sprites/alex_%s.png" % k)
		tr.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		tr.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		tr.custom_minimum_size = Vector2(120, 170)
		col.add_child(tr)
		var l := _lbl(caps[k], 15, Color("cfe8ff"))
		l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		col.add_child(l)
	var info := _lbl("A / D or arrows: walk     F: flashlight     ESC: pause\nCollect keys and cards, solve puzzles, avoid cameras (crouch beside crates).\nOn phones use the on-screen buttons.", 18, Color("cfe8ff"))
	info.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vb.add_child(info)
	var back := _btn("BACK", func(): _show(_main))
	back.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	vb.add_child(back)


func _show(which: Control) -> void:
	_main.visible = which == _main
	_levels.visible = which == _levels
	_how.visible = which == _how


func _lbl(t: String, sz: int, c: Color) -> Label:
	var l := Label.new()
	l.text = t
	l.add_theme_font_size_override("font_size", sz)
	l.add_theme_color_override("font_color", c)
	l.add_theme_color_override("font_outline_color", Color(0.02, 0.05, 0.12))
	l.add_theme_constant_override("outline_size", 8)
	return l


func _btn(t: String, cb: Callable) -> Button:
	var b := Button.new()
	b.text = t
	b.custom_minimum_size = Vector2(340, 60)
	b.add_theme_font_size_override("font_size", 24)
	b.pressed.connect(cb)
	return b


func _process(delta: float) -> void:
	_t += delta
	if _hero != null:
		_hero.pivot_offset = _hero.size / 2.0
		_hero.rotation = sin(_t * 1.3) * 0.015
		_hero.scale = Vector2.ONE * (1.0 + sin(_t * 2.0) * 0.01)
	queue_redraw()


func _draw() -> void:
	var sz := size
	draw_rect(Rect2(Vector2.ZERO, sz), Color("070b1c"))
	for i in 14:
		draw_rect(Rect2(0, sz.y * float(i) / 14.0, sz.x, sz.y / 14.0 + 1.0), Color(0.08, 0.28, 0.55, 0.035 * float(i)))
	# silhouette of lab machinery
	for i in 9:
		var bx := fmod(float(i) * 233.0 + 40.0, sz.x)
		var bh := 90.0 + float((i * 53) % 140)
		draw_rect(Rect2(bx, sz.y - bh, 120.0, bh), Color(0.05, 0.1, 0.2, 0.9))
		draw_rect(Rect2(bx + 14.0, sz.y - bh + 14.0, 92.0, 8.0), Color(0.2, 0.8, 1.0, 0.25))
	var step := 64.0
	var x := -fmod(_t * 12.0, step)
	while x < sz.x:
		draw_line(Vector2(x, 0), Vector2(x, sz.y), Color(0.25, 0.8, 1.0, 0.05), 1.0)
		x += step
	for i in 50:
		var px := fmod(float(i) * 137.5 + _t * (10.0 + float(i % 5) * 6.0), sz.x)
		var py := fmod(float(i) * 71.3 + 100.0 + sin(_t * 0.5 + float(i)) * 20.0, sz.y)
		draw_circle(Vector2(px, py), 1.5 + float(i % 3), Color(0.3, 0.9, 1.0, 0.25))
	# glowing pad under Alex
	var c := Vector2(sz.x - 260.0, sz.y * 0.5 + 215.0)
	for i in 5:
		draw_arc(c, 150.0 - float(i) * 22.0, 0, TAU, 48, Color(0.25, 0.85, 1.0, 0.5 - 0.08 * float(i)), 3.0)
	draw_rect(Rect2(0, 0, sz.x, 6), Color(0.25, 0.85, 1.0, 0.6))
