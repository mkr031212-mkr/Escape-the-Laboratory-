extends "res://scripts/level_base.gd"
## LEVEL 1 - THE AWAKENING (Laboratory reception).

const PASSWORD := "4721"
var _door
var _lock
var _board
var _computer
var _tut: int = 0
var _tut_cd: float = 0.0


func _setup() -> void:
	level_number = 1
	width = 3000.0
	variant = 0
	ambient = Color(0.40, 0.44, 0.62)
	bg_signs = [[1000.0, "RECEPTION"], [2560.0, "MAIN EXIT"]]
	spawn_point = Vector2(110, 440.0 - 28.0)
	checkpoint = spawn_point


func _build() -> void:
	# start platform + ladder, jump obstacle
	add_platform(30, 440, 200)
	add_ladder(205, 440)
	deco("crate", 120, 440, 46, 36, Color("8a6a43"))
	deco("vent", 120, 300, 70, 70)
	add_crate(480, floor_y, 56, 56, false)
	# reception: desk + computer, two chairs
	deco("chair", 640, floor_y, 40, 50, Color("2f58a8"))
	deco("chair", 880, floor_y, 40, 50, Color("2f58a8"))
	deco("desk", 760, floor_y, 150, 66, Color("6f7f9c"))
	_computer = make_prop("computer", Vector2(760, floor_y - 66), Vector2(64, 64), "Use computer", Callable(), true)
	_computer.tint = Color("7df9ff")
	_computer.text = "WELCOME BACK, ALEX."
	_computer.on_interact = func(p): _use_computer(p)
	# notice board with password note
	_board = make_prop("board", Vector2(1070, floor_y - 120), Vector2(110, 80), "Read notice board", Callable(), true, "note")
	_board.on_interact = func(p): _use_board(p)
	# wooden drawer unit (small silver key)
	var dr = make_prop("drawer", Vector2(1290, floor_y), Vector2(90, 70), "Search drawer", Callable(), true)
	dr.on_interact = func(p): _use_drawer(p)
	# grey storage lockers + wooden storage cabinet (blue access card)
	deco("locker", 1450, floor_y, 100, 130, Color("7d8aa5"))
	var cab = make_prop("cabinet", Vector2(1660, floor_y), Vector2(100, 150), "Open storage cabinet", Callable(), true)
	cab.on_interact = func(p): _use_cabinet(p)
	# security camera + broken ceiling light + clock
	var cam = add_camera(Vector2(1260, ceiling_y + 110), 0.0, 100.0, 150.0, 1.0, 0.4)
	cam.active = false
	deco("clock", 2150, floor_y - 150, 46, 46)
	# blue laboratory door + electronic lock
	_door = make_prop("door", Vector2(1960, floor_y), Vector2(80, 130), "Enter laboratory", Callable(), true, "RESEARCH LAB")
	_door.tint = Color("2f5fa8")
	_door.on_interact = func(p): _use_door(p)
	_lock = make_prop("doorlock", Vector2(2070, floor_y - 70), Vector2(28, 44), "Electronic lock", Callable(), true)
	_lock.on_interact = func(p): _use_lock(p)
	# main exit (sealed)
	var ex = make_prop("exit_door", Vector2(2620, floor_y), Vector2(90, 140), "Main exit", Callable(), true, "EXIT")
	ex.on_interact = func(_p): err("The main exit is sealed from the other side.")
	# lights
	add_lamp(Vector2(300, ceiling_y + 30), Color(1.0, 0.9, 0.7), 0.7, 2.4, true)
	add_lamp(Vector2(900, ceiling_y + 30), Color(1.0, 0.9, 0.7), 0.9, 2.6, true)   # broken, flickering
	add_lamp(Vector2(1500, ceiling_y + 30), Color(0.9, 0.95, 1.0), 0.8, 2.6)
	add_lamp(Vector2(2000, ceiling_y + 30), Color(0.7, 0.85, 1.0), 0.8, 2.6)
	add_lamp(Vector2(2600, ceiling_y + 30), Color(0.6, 1.0, 0.7), 0.8, 2.6)


func _start() -> void:
	player.wake_timer = player.WAKE_TIME
	objective("Wake up and look around")
	await get_tree().create_timer(player.WAKE_TIME + 0.2).timeout
	await say([["Alex", "Ugh... my head. Where am I?", "normal"],
		["Alex", "An underground lab? The main exit is sealed. I need to find a way out.", ""]])
	objective("Explore the reception room")
	_tut = 1


func _process(delta: float) -> void:
	super(delta)
	if player == null or hud == null:
		return
	var x: float = player.global_position.x
	match _tut:
		1:
			hud.set_hint(ctl("Walk: A / D or arrow keys", "Walk: use the arrow buttons (bottom left)"))
			if x > 330.0:
				_tut = 2
		2:
			hud.set_hint(ctl("Climb down the ladder: hold S, then JUMP over the crate (Space)", "Climb down the ladder (DOWN button), then JUMP over the crate"))
			if x > 560.0:
				_tut = 3
		3:
			hud.set_hint(ctl("Hold SHIFT to run", "Hold RUN to run faster"))
			if absf(player.velocity.x) > 250.0 or x > 900.0:
				_tut = 4
		4:
			hud.set_hint(ctl("Press E near objects to interact", "Press USE near objects to interact"))
			if Game.has_item("small_key") or x > 1400.0:
				_tut = 5
				hud.set_hint("")


func _use_drawer(p) -> void:
	if p.done:
		toast("The drawer is empty.")
		return
	p.done = true
	p.refresh()
	Sfx.play("door")
	give("small_key", "Small Silver Key")
	objective("Find what the silver key opens")


func _use_cabinet(p) -> void:
	if p.done:
		toast("Nothing else inside.")
		return
	if not Game.has_item("small_key"):
		err("The storage cabinet is locked. I need a small key.")
		return
	p.done = true
	p.refresh()
	Sfx.play("door")
	Game.remove_item("small_key")
	give("access_card", "Blue Access Card")
	objective("Check the notice board and use the computer")


func _use_board(p) -> void:
	if p.done:
		toast("Password note: " + PASSWORD)
		return
	p.done = true
	p.refresh()
	give("note", "Password Note")
	await say([["Alex", "A sticky note: 'Terminal password: %s. Don't tell ECHO.'" % PASSWORD, ""],
		["Alex", "ECHO? Whatever that is, this must be for the computer.", ""]])
	objective("Use the reception computer")


func _use_computer(p) -> void:
	if p.done:
		return
	if not Game.has_item("note"):
		err("PASSWORD REQUIRED. Look around the room for a clue.")
		return
	var ok: bool = await hud.run_puzzle("keypad", PASSWORD)
	if not ok:
		return
	p.done = true
	p.refresh()
	Sfx.play("power")
	await say([["SYSTEM", "Login accepted. Unlocking laboratory systems...", ""],
		["SYSTEM", "WELCOME BACK, ALEX. WE HAVE BEEN WAITING FOR YOU.", ""]])
	await hud.fade_to(1.0, 0.5)
	await get_tree().create_timer(1.3).timeout
	_lock.locked = false
	_lock.refresh()
	Sfx.play("door")
	await hud.fade_to(0.0, 0.8)
	toast("ELECTRONIC LOCK POWERED")
	objective("Use the blue access card on the door lock")
	await say([["Alex", "'We have been waiting for you'... Who?", ""]])


func _use_lock(p) -> void:
	if _lock.locked:
		err("The lock has no power. Maybe the computer controls it.")
	elif not Game.has_item("access_card"):
		err("ACCESS CARD REQUIRED")
	else:
		_door.locked = false
		_door.done = true
		_door.refresh()
		p.done = true
		Sfx.play("door")
		toast("DOOR UNLOCKED")
		objective("Enter the research laboratory")


func _use_door(p) -> void:
	if p.locked:
		err("The laboratory door is locked.")
		return
	Sfx.play("door")
	finish_level("LEVEL 1 COMPLETED", "The Awakening")
