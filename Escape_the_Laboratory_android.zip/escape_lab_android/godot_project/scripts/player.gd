extends CharacterBody2D
## Alex: walk, run, jump, crouch, climb ladders, interact, flashlight. Drawn procedurally.

const WAKE_TIME := 2.6
const SPR_SCALE := 0.205
const WALK := 170.0
const RUN := 285.0
const CROUCH_SPEED := 75.0
const JUMP_V := -430.0
const GRAVITY := 1150.0
const CLIMB := 120.0
const STAND_H := 56.0
const CROUCH_H := 34.0

const SKIN := Color("f2bd8e")
const HAIR := Color("5b3422")
const JACKET := Color("2f6ee0")
const JACKET_D := Color("1f4fb0")
const PANTS := Color("1c2150")
const BOOT := Color("39408c")
const CYAN := Color("3fd8ff")
const PACK := Color("2a2f45")
const GLOVE := Color("15182e")

var facing: int = 1
var crouching: bool = false
var climbing: bool = false
var control_enabled: bool = true
var wake_timer: float = 0.0
var ladders: Array = []
var nearby: Array = []
var _t: float = 0.0
var _act: float = 0.0
var _coyote: float = 0.0
var _jump_buf: float = 0.0
var _climb_phase: float = 0.0
var _step_t: float = 0.0
var _cam: Camera2D
var _beam: PointLight2D
var _glow: PointLight2D
var _shape: CollisionShape2D
var _ceiling: RayCast2D
var _sprite: Sprite2D
var _tex: Dictionary = {}


func _ready() -> void:
	add_to_group("player")
	_shape = $Shape
	_ceiling = $CeilingCheck
	for n in ["idle", "run", "jump", "crouch", "climb", "interact"]:
		_tex[n] = load("res://assets/sprites/alex_%s.png" % n)
	_sprite = Sprite2D.new()
	add_child(_sprite)
	_cam = Camera2D.new()
	_cam.zoom = Vector2(1.5, 1.5)
	_cam.position = Vector2(0, -30)
	_cam.position_smoothing_enabled = true
	_cam.position_smoothing_speed = 7.0
	add_child(_cam)
	_cam.make_current()
	_beam = _make_light(2.8, 1.1, Color(1.0, 0.95, 0.8))
	_glow = _make_light(0.9, 0.55, Color(0.8, 0.9, 1.0))


func _make_light(sc: float, en: float, col: Color) -> PointLight2D:
	var l := PointLight2D.new()
	l.texture = Game.light_texture()
	l.texture_scale = sc
	l.energy = en
	l.color = col
	add_child(l)
	return l


func set_limits(l: int, t: int, r: int, b: int) -> void:
	_cam.limit_left = l
	_cam.limit_top = t
	_cam.limit_right = r
	_cam.limit_bottom = b


func teleport(pos: Vector2) -> void:
	global_position = pos
	velocity = Vector2.ZERO
	_end_climb()
	_cam.reset_smoothing()


func add_nearby(p) -> void:
	if not nearby.has(p):
		nearby.append(p)


func remove_nearby(p) -> void:
	nearby.erase(p)


func enter_ladder(a) -> void:
	if not ladders.has(a):
		ladders.append(a)


func exit_ladder(a) -> void:
	ladders.erase(a)


func current_target():
	var best = null
	var bd := 1.0e9
	for p in nearby:
		if is_instance_valid(p) and p.enabled and p.interactive:
			var d: float = absf(p.global_position.x - global_position.x)
			if d < bd:
				bd = d
				best = p
	return best


func _ladder_top() -> float:
	var top := 1.0e9
	for l in ladders:
		top = minf(top, l.top_y())
	return top


func _set_crouch(c: bool) -> void:
	if c == crouching:
		return
	crouching = c
	var h := CROUCH_H if c else STAND_H
	(_shape.shape as RectangleShape2D).size = Vector2(26.0, h)
	_shape.position.y = 28.0 - h / 2.0


func _start_climb() -> void:
	climbing = true
	collision_mask = 1
	velocity = Vector2.ZERO
	_set_crouch(false)
	var best = ladders[0]
	for l in ladders:
		if absf(l.global_position.x - global_position.x) < absf(best.global_position.x - global_position.x):
			best = l
	global_position.x = best.global_position.x


func _end_climb() -> void:
	climbing = false
	collision_mask = 3


func _physics_process(delta: float) -> void:
	_t += delta
	_act = maxf(0.0, _act - delta)
	if wake_timer > 0.0 or not control_enabled:
		wake_timer = maxf(0.0, wake_timer - delta)
		velocity.x = move_toward(velocity.x, 0.0, 1500.0 * delta)
		velocity.y += GRAVITY * delta
		move_and_slide()
		queue_redraw()
		return
	var dir := Input.get_axis("move_left", "move_right")
	var up := Input.is_action_pressed("move_up")
	var down := Input.is_action_pressed("move_down")
	var feet_y := global_position.y + 28.0
	if is_on_floor():
		_coyote = 0.1
	else:
		_coyote -= delta
	if Input.is_action_just_pressed("jump"):
		_jump_buf = 0.12
	else:
		_jump_buf -= delta
	if Input.is_action_just_pressed("flashlight"):
		_beam.visible = not _beam.visible
	if Input.is_action_just_pressed("interact"):
		var tgt = current_target()
		if tgt != null:
			_act = 0.3
			tgt.interact()

	if not climbing and not ladders.is_empty():
		var top := _ladder_top()
		if up and feet_y > top + 26.0:
			_start_climb()
		elif down and is_on_floor() and feet_y <= top + 26.0:
			global_position.y += 8.0
			_start_climb()
		elif down and not is_on_floor():
			_start_climb()
	if climbing:
		if ladders.is_empty():
			_end_climb()
		elif Input.is_action_just_pressed("jump"):
			_end_climb()
			velocity.y = JUMP_V * 0.75
			velocity.x = dir * WALK
			_jump_buf = 0.0
		else:
			velocity.x = 0.0
			velocity.y = (float(down) - float(up)) * CLIMB
			if velocity.y != 0.0:
				_climb_phase += delta * 11.0
			move_and_slide()
			if velocity.y > 0.0 and is_on_floor():
				_end_climb()
			queue_redraw()
			return

	var want_crouch: bool = down and is_on_floor()
	if crouching and not want_crouch:
		_ceiling.force_raycast_update()
		if _ceiling.is_colliding():
			want_crouch = true
	_set_crouch(want_crouch)
	var speed := WALK
	if crouching:
		speed = CROUCH_SPEED
	elif Input.is_action_pressed("run"):
		speed = RUN
	if dir != 0.0:
		facing = 1 if dir > 0.0 else -1
	velocity.x = move_toward(velocity.x, dir * speed, 2200.0 * delta)
	if not is_on_floor():
		velocity.y += GRAVITY * delta
	if _jump_buf > 0.0 and _coyote > 0.0 and not crouching:
		velocity.y = JUMP_V
		_jump_buf = 0.0
		_coyote = 0.0
		Sfx.play("jump")
	if Input.is_action_just_released("jump") and velocity.y < -150.0:
		velocity.y *= 0.5
	move_and_slide()
	if is_on_floor() and absf(velocity.x) > 60.0:
		_step_t -= delta
		if _step_t <= 0.0:
			_step_t = 0.3 if absf(velocity.x) < 200.0 else 0.2
			Sfx.play("step")
	_beam.position = Vector2(facing * 70.0, -8.0)
	queue_redraw()


# ---------------------------------------------------------------- sprite
func _process(_d: float) -> void:
	var state := "idle"
	if climbing:
		state = "climb"
	elif not is_on_floor():
		state = "jump"
	elif crouching:
		state = "crouch"
	elif _act > 0.0:
		state = "interact"
	elif absf(velocity.x) > 25.0:
		state = "run"
	var tex: Texture2D = _tex[state]
	var sc := SPR_SCALE
	if state == "crouch":
		sc *= 0.85
	var w := float(tex.get_width()) * sc
	var h := float(tex.get_height()) * sc
	var pos := Vector2(0.0, 28.0 - h / 2.0)
	var rot := 0.0
	var squash := Vector2.ONE
	var flip := facing < 0
	if state == "idle":
		squash = Vector2(1.0, 1.0 + sin(_t * 2.2) * 0.012)
	elif state == "run":
		var spd := 16.0 if absf(velocity.x) > 200.0 else 10.0
		pos.y -= absf(sin(_t * spd * 0.5)) * 3.0
		rot = sin(_t * spd * 0.5) * 0.03 * float(facing)
		pos.x = 5.0 * float(facing)
	elif state == "jump":
		pos.x = 2.0 * float(facing)
	elif state == "interact":
		pos.x = -0.1 * w * float(facing)
	elif state == "climb":
		flip = int(floor(_climb_phase / 2.4)) % 2 == 0
	if wake_timer > 0.0:
		var p := clampf((WAKE_TIME - wake_timer - 1.2) / 1.2, 0.0, 1.0)
		p = p * p * (3.0 - 2.0 * p)
		rot = -PI / 2.0 * (1.0 - p)
		pos = Vector2(0.0, lerpf(28.0 - w / 2.0, 28.0 - h / 2.0, p))
		flip = false
		tex = _tex["idle"]
		w = float(tex.get_width()) * SPR_SCALE
		h = float(tex.get_height()) * SPR_SCALE
		sc = SPR_SCALE
		pos.y = lerpf(28.0 - w / 2.0, 28.0 - h / 2.0, p)
	_sprite.texture = tex
	_sprite.flip_h = flip
	_sprite.position = pos
	_sprite.rotation = rot
	_sprite.scale = Vector2(sc, sc) * squash
