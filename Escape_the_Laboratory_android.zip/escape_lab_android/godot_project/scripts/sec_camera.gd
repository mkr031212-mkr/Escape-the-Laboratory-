extends Node2D
## Sweeping security camera. Player is spotted inside the red cone unless crouching beside cover.

var level = null
var sweep_from: float = 55.0
var sweep_to: float = 125.0
var range_len: float = 340.0
var fov: float = 24.0
var speed: float = 0.9
var mount_len: float = 0.0
var active: bool = true
var _angle: float = 90.0
var _t: float = 0.0


func _ready() -> void:
	var m := CanvasItemMaterial.new()
	m.light_mode = CanvasItemMaterial.LIGHT_MODE_UNSHADED
	material = m
	_t = randf() * 3.0


func _process(delta: float) -> void:
	if active:
		_t += delta * speed
		_angle = lerpf(sweep_from, sweep_to, 0.5 + 0.5 * sin(_t))
		var p = level.player
		if p != null and p.control_enabled and p.wake_timer <= 0.0:
			var to: Vector2 = p.global_position - global_position
			if to.length() < range_len:
				var diff := absf(wrapf(rad_to_deg(to.angle()) - _angle + 180.0, 0.0, 360.0) - 180.0)
				if diff < fov and not level.player_hidden():
					level.camera_spotted()
	queue_redraw()


func _draw() -> void:
	if mount_len > 0.0:
		draw_line(Vector2.ZERO, Vector2(0, -mount_len), Color("5d6a80"), 4.0)
	draw_set_transform(Vector2.ZERO, deg_to_rad(_angle), Vector2.ONE)
	draw_rect(Rect2(-7, -6, 18, 12), Color("c9d0e0"))
	draw_circle(Vector2(11, 0), 4.0, Color("ff3b3b") if active else Color("3a8a5a"))
	if active:
		var pts := PackedVector2Array([Vector2.ZERO])
		var n := 8
		for i in n + 1:
			var a := deg_to_rad(-fov + 2.0 * fov * float(i) / float(n))
			pts.append(Vector2(cos(a), sin(a)) * range_len)
		draw_colored_polygon(pts, Color(1.0, 0.15, 0.15, 0.17))
