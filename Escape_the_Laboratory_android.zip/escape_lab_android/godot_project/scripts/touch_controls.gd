extends Control
## Multi-touch on-screen controls. Presses InputMap actions, so the player script is input-agnostic.

var hud = null
var _touches: Dictionary = {}   # touch index -> action
var _held: Dictionary = {}      # action -> count


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	visible = Game.touch_enabled


func _exit_tree() -> void:
	_release_all()


func _release_all() -> void:
	for a in _held.keys():
		Input.action_release(a)
	_held.clear()
	_touches.clear()


func _layout() -> Dictionary:
	var s := get_viewport_rect().size
	var c := Vector2(170, s.y - 130)
	return {
		"move_left": [c + Vector2(-80, 0), 40.0],
		"move_right": [c + Vector2(80, 0), 40.0],
		"move_up": [c + Vector2(0, -78), 40.0],
		"move_down": [c + Vector2(0, 78), 40.0],
		"jump": [Vector2(s.x - 120, s.y - 130), 54.0],
		"interact": [Vector2(s.x - 270, s.y - 100), 44.0],
		"run": [Vector2(s.x - 120, s.y - 265), 36.0],
		"flashlight": [Vector2(s.x - 262, s.y - 235), 32.0],
	}


func _hit(pos: Vector2) -> String:
	var best := ""
	var bd := 1.0e9
	var lay := _layout()
	for a in lay.keys():
		var d: float = pos.distance_to(lay[a][0])
		if d < float(lay[a][1]) + 16.0 and d < bd:
			bd = d
			best = a
	return best


func _press(a: String) -> void:
	_held[a] = int(_held.get(a, 0)) + 1
	Input.action_press(a)


func _release(a: String) -> void:
	_held[a] = int(_held.get(a, 0)) - 1
	if _held[a] <= 0:
		_held.erase(a)
		Input.action_release(a)


func _input(event: InputEvent) -> void:
	if not visible:
		return
	if event is InputEventScreenTouch:
		var i: int = event.index
		if event.pressed:
			if hud != null and hud.dialog_active:
				return
			var a := _hit(event.position)
			if a != "":
				_touches[i] = a
				_press(a)
		elif _touches.has(i):
			_release(_touches[i])
			_touches.erase(i)
	elif event is InputEventScreenDrag:
		var j: int = event.index
		if _touches.has(j):
			var a2 := _hit(event.position)
			if a2 != _touches[j]:
				_release(_touches[j])
				_touches.erase(j)
				if a2 != "":
					_touches[j] = a2
					_press(a2)
	queue_redraw()


func _process(_d: float) -> void:
	visible = Game.touch_enabled
	if visible:
		queue_redraw()


func _draw() -> void:
	var lay := _layout()
	var labels := {"jump": "JUMP", "interact": "USE", "run": "RUN", "flashlight": "LIGHT"}
	var font := ThemeDB.fallback_font
	for a in lay.keys():
		var p: Vector2 = lay[a][0]
		var r: float = lay[a][1]
		var on := _held.has(a)
		draw_circle(p, r + 5.0, Color(0.25, 0.85, 1.0, 0.10))
		draw_circle(p, r, Color(0.04, 0.12, 0.26, 0.78) if not on else Color(0.12, 0.6, 0.85, 0.92))
		draw_circle(p, r * 0.78, Color(1, 1, 1, 0.06))
		draw_arc(p, r, 0, TAU, 40, Color(0.35, 0.9, 1.0, 0.95), 3.0)
		if labels.has(a):
			var tx: String = labels[a]
			var fs := 18 if r > 40.0 else 14
			var pos := p + Vector2(-r, float(fs) * 0.35)
			draw_string_outline(font, pos, tx, HORIZONTAL_ALIGNMENT_CENTER, r * 2.0, fs, 4, Color(0, 0.05, 0.1))
			draw_string(font, pos, tx, HORIZONTAL_ALIGNMENT_CENTER, r * 2.0, fs, Color.WHITE)
		else:
			var d := Vector2.ZERO
			match a:
				"move_left": d = Vector2(-1, 0)
				"move_right": d = Vector2(1, 0)
				"move_up": d = Vector2(0, -1)
				"move_down": d = Vector2(0, 1)
			var n := Vector2(-d.y, d.x)
			draw_colored_polygon(PackedVector2Array([p + d * 17.0, p - d * 11.0 + n * 15.0, p - d * 11.0 - n * 15.0]), Color(1, 1, 1, 0.95))
