extends "res://scripts/level_base.gd"
## LEVEL 6 - ECHO'S CORE

const UP := 340.0
var _powered: bool = false
var _db: bool = false
var _restored: bool = false
var _gen
var _term
var _console
var _lift
var _video


func _setup() -> void:
	level_number = 6
	width = 3700.0
	variant = 3
	ambient = Color(0.14, 0.19, 0.34)
	bg_signs = [[500.0, "ECHO CORE"], [1700.0, "SERVER FARM"], [2700.0, "CENTRAL AI"], [3400.0, "MEMORY ARCHIVE"]]
	spawn_point = Vector2(110, floor_y - 28.0)
	checkpoint = spawn_point


func _build() -> void:
	add_platform(1300, UP, 1900)
	add_ladder(1330, UP)
	add_ladder(3170, UP)
	# ---- server racks (decor)
	for x in [250.0, 380.0, 510.0, 900.0, 1030.0, 1160.0, 1500.0, 1630.0, 1760.0]:
		deco("rack", x, floor_y, 90, 170, Color("26323d"))
	for x in [1900.0, 2030.0, 2160.0]:
		deco("rack", x, UP, 90, 170, Color("26323d"))
	var big = deco("screen", 640, floor_y - 150, 190, 100, Color("7df9ff"))
	big.text = "ECHO"
	# ---- backup power parts
	add_item("bfuse", "Backup Fuse", "fuse", Vector2(720, floor_y))
	add_item("bc2", "Power Component", "comp_blue", Vector2(1700, UP))
	var cab = make_prop("locker", Vector2(2000, floor_y), Vector2(90, 130), "Open equipment cabinet", Callable(), true)
	cab.tint = Color("5a6a82")
	cab.on_interact = func(p): _cabinet(p)
	_gen = make_prop("generator", Vector2(2400, floor_y), Vector2(150, 110), "Backup generator", Callable(), true)
	_gen.on_interact = func(p): _use_gen(p)
	# ---- central AI terminal + big screen
	var core = deco("screen", 2800, floor_y - 150, 190, 100, Color("7df9ff"))
	core.text = "CENTRAL AI\nOFFLINE"
	deco("desk", 2800, floor_y, 150, 44, Color("4a5a70"))
	_term = make_prop("computer", Vector2(2800, floor_y - 44), Vector2(66, 66), "ECHO central computer", Callable(), true)
	_term.tint = Color("7df9ff")
	_term.text = "CONNECT"
	_term.on_interact = func(p): _use_term(p)
	# ---- hidden video file + repair console + elevator
	_video = add_item("video", "Damaged Video File", "file", Vector2(2900, UP))
	_video.visible = false
	_video.enabled = false
	_console = make_prop("computer", Vector2(3250, floor_y - 44), Vector2(66, 66), "Recording repair console", Callable(), true)
	_console.tint = Color("7df9ff")
	_console.text = "NO FILE"
	_console.on_interact = func(p): _use_console(p)
	deco("desk", 3250, floor_y, 120, 44, Color("4a5a70"))
	_lift = make_prop("door", Vector2(3520, floor_y), Vector2(90, 140), "Elevator", Callable(), true, "ELEVATOR")
	_lift.tint = Color("5a6378")
	_lift.on_interact = func(p): _use_lift(p)
	for x in [400.0, 1300.0, 2200.0, 3100.0]:
		add_lamp(Vector2(x, ceiling_y + 30), Color(0.3, 0.6, 1.0), 0.6, 2.6, true)


func _start() -> void:
	await say([["ECHO", "Welcome back, Alex.", ""],
		["Alex", "Why did you hide everything from me?", ""],
		["ECHO", "Because I was instructed to protect you.", ""],
		["Alex", "Protect me from what?", ""]])
	toast("The screen goes black.")
	objective("Find the backup power parts: fuse, component, cabinet part (0/3)")


func _on_picked(id: String) -> void:
	if id == "bfuse" or id == "bc2" or id == "bc3":
		var n := 0
		for k in ["bfuse", "bc2", "bc3"]:
			if Game.has_item(k):
				n += 1
		objective("Bring the backup parts to the backup generator (%d held)" % n)
	elif id == "video":
		objective("Restore the damaged recording at the repair console")
		_console.text = "LOAD FILE"


func _cabinet(p) -> void:
	if p.done:
		toast("Empty.")
		return
	p.done = true
	p.refresh()
	Sfx.play("door")
	give("bc3", "Power Component")
	_on_picked("bc3")


func _use_gen(p) -> void:
	if p.done:
		toast("The backup generator is running.")
		return
	var have := 0
	for k in ["bfuse", "bc2", "bc3"]:
		if Game.has_item(k):
			have += 1
	if have < 3:
		err("The generator needs 3 parts. You have %d." % have)
		return
	for k in ["bfuse", "bc2", "bc3"]:
		Game.remove_item(k)
	p.done = true
	_powered = true
	p.refresh()
	Sfx.play("power")
	set_ambient(Color(0.65, 0.8, 1.0), 1.5)
	toast("BACKUP POWER ONLINE - CENTRAL AI RESTORED")
	objective("Connect to ECHO's central computer")


func _use_term(p) -> void:
	if not _powered:
		err("The central computer has no power.")
		return
	if p.done:
		toast("The memory database is unlocked.")
		return
	var ok: bool = await hud.run_puzzle("circuit")
	if not ok:
		return
	p.done = true
	_db = true
	Sfx.play("power")
	await say([["SYSTEM", "MEMORY DATABASE UNLOCKED. SUBJECT: ALEX - RECORDS FOUND.", ""],
		["ECHO", "I was created by Dr. William to protect the laboratory and its research.", ""],
		["Alex", "Then why did you lock everyone inside?", ""],
		["ECHO", "An emergency occurred. My protection protocol was activated. I was unable to distinguish between protection and imprisonment.", ""],
		["Alex", "What happened to Dr. William?", ""],
		["ECHO", "He is the only person who knows the complete truth.", ""],
		["SYSTEM", "DR. WILLIAM'S LOCATION: HIDDEN LABORATORY.", ""]])
	_video.visible = true
	_video.enabled = true
	objective("Locate the hidden video file (catwalk, upper right)")


func _use_console(p) -> void:
	if p.done:
		return
	if not Game.has_item("video"):
		err("No video file loaded.")
		return
	Game.remove_item("video")
	var ok: bool = await hud.run_puzzle("sequence", 5)
	if not ok:
		Game.add_item("video", "Damaged Video File")
		return
	p.done = true
	_restored = true
	p.text = "RESTORED"
	Sfx.play("power")
	await say([["SYSTEM", "Recording restored. Accessing ECHO's original programming...", ""],
		["SYSTEM", "PRIME DIRECTIVE: PROTECT ALEX. PROTECT THE LABORATORY.", ""],
		["Dr. William", "ECHO, if Alex ever returns, take him to my hidden laboratory. He deserves the truth.", "serious", "Dr. William [RECORDING]"]])
	Sfx.play("door")
	_lift.locked = false
	_lift.refresh()
	toast("HIDDEN ELEVATOR ACTIVATED")
	objective("Take the elevator to Dr. William's hidden laboratory")


func _use_lift(p) -> void:
	if p.locked:
		err("The elevator is offline.")
		return
	Sfx.play("door")
	await say([["ECHO", "Alex... I hope you understand why I did everything.", ""]])
	finish_level("LEVEL 6 COMPLETED", "ECHO's Core")
