extends "res://scripts/level_base.gd"
## LEVEL 2 - THE RESEARCH LABORATORY (main research room, electrical room, storage, security door).

const UP := 330.0   # upper floor height
var _panel
var _generator
var _cab_pc
var _door
var _powered: bool = false
var _comps: int = 0


func _setup() -> void:
	level_number = 2
	width = 3300.0
	variant = 1
	ambient = Color(0.22, 0.27, 0.38)
	bg_signs = [[420.0, "AREA 1 - RESEARCH"], [2330.0, "AREA 2 - ELECTRICAL", 130.0], [2100.0, "AREA 3 - STORAGE"], [3100.0, "AREA 4 - SECURITY"]]
	spawn_point = Vector2(110, floor_y - 28.0)
	checkpoint = spawn_point


func _build() -> void:
	add_platform(100, UP, 2700)
	add_ladder(160, UP)
	add_ladder(1860, UP)
	add_ladder(2760, UP)
	# ---- AREA 1 upper: computers, notebook desk, documents, photo, failed experiment, CCTV
	deco("desk", 300, UP, 150, 56, Color("5f7088"))
	var rec = make_prop("computer", Vector2(300, UP - 56), Vector2(64, 64), "Play recorded message", Callable(), true)
	rec.tint = Color("7df9ff")
	rec.text = "REC: DR. WILLIAM"
	rec.done = true
	rec.on_interact = func(_p): _recording()
	deco("desk", 600, UP, 160, 56, Color("5f7088"))
	add_item("notebook", "Dr. William's Notebook", "book", Vector2(600, UP - 60))
	deco("desk", 830, UP, 120, 50, Color("5f7088"))
	var ph = make_prop("photo", Vector2(1000, UP - 110), Vector2(40, 50), "Look at photo", Callable(), true)
	ph.on_interact = func(_p): say([["Alex", "A photo of a scientist in a lab coat... 'Dr. William, Project ECHO lead'.", ""]])
	var fail = make_prop("screen", Vector2(1200, UP - 40), Vector2(130, 70), "Read screen", Callable(), true)
	fail.tint = Color("ff7070")
	fail.text = "PROJECT ECHO:\nEXPERIMENT FAILED"
	fail.on_interact = func(_p): _failed_screen()
	deco("desk", 1200, UP, 150, 40, Color("5f7088"))
	var cctv = make_prop("cctv", Vector2(1480, UP - 100), Vector2(100, 60), "Watch CCTV", Callable(), true)
	cctv.on_interact = func(p): _cctv(p)
	# ---- AREA 1 lower: locked drawer (red), shelves, chamber, broken machine (blue)
	var dr = make_prop("drawer", Vector2(330, floor_y), Vector2(100, 70), "Search drawer", Callable(), true)
	dr.on_interact = func(p): _drawer(p)
	deco("shelf", 640, floor_y, 120, 130, Color("46506f"))
	deco("photo", 900, floor_y - 120, 40, 50)
	deco("chamber", 1150, floor_y, 170, 140)
	deco("machine", 1420, floor_y, 120, 100)
	add_item("comp_blue", "Blue Power Component", "comp_blue", Vector2(1520, floor_y))
	# ---- AREA 3 storage: cabinets, green component, equipment boxes, computer cabinet
	deco("locker", 2000, floor_y, 100, 130, Color("6a7690"))
	var st = make_prop("locker", Vector2(2150, floor_y), Vector2(100, 130), "Open storage cabinet", Callable(), true)
	st.tint = Color("6a7690")
	st.on_interact = func(p): _storage(p)
	deco("crate", 2330, floor_y, 60, 44, Color("8a6a43"))
	deco("crate", 2400, floor_y, 50, 34, Color("8a6a43"))
	_cab_pc = make_prop("cabinet_pc", Vector2(2620, floor_y), Vector2(100, 140), "Computer cabinet", Callable(), true)
	_cab_pc.on_interact = func(p): _cabinet_pc(p)
	# ---- AREA 2 upper: generator + control panel
	_generator = deco("generator", 2330, UP, 150, 100)
	_panel = make_prop("panel", Vector2(2580, UP), Vector2(120, 100), "Electrical panel", Callable(), true)
	_panel.on_interact = func(p): _use_panel(p)
	# ---- AREA 4: security door
	_door = make_prop("door", Vector2(3150, floor_y), Vector2(90, 140), "Security door", Callable(), true, "SECURITY")
	_door.tint = Color("4a5368")
	_door.on_interact = func(p): _use_door(p)
	for x in [300.0, 1200.0, 2200.0, 3000.0]:
		add_lamp(Vector2(x, ceiling_y + 30), Color(1.0, 0.25, 0.25), 0.5, 2.0, true)


func _start() -> void:
	objective("Find the 3 power components (0/3)")
	await say([["Alex", "The blue access card worked. This must be the main research room.", ""],
		["Alex", "It is pitch dark. Press F for my flashlight, and look for power.", ""]])
	hud.set_hint(ctl("Crouch with S. Climb ladders with W / S. Flashlight: F", "Climb ladders with UP / DOWN. LIGHT toggles the flashlight"))
	await get_tree().create_timer(6.0).timeout
	hud.set_hint("")


func _recording() -> void:
	await say([["Dr. William", "Alex, if you can hear me, please listen carefully.", "serious", "Dr. William [RECORDING]"],
		["Dr. William", "Something went wrong in this laboratory. Don't trust everything you see.", "worried", "Dr. William [RECORDING]"],
		["Dr. William", "Restore the generator. Three power components are hidden in the lab: red, blue and green.", "normal", "Dr. William [RECORDING]"]])


func _failed_screen() -> void:
	await say([["SYSTEM", "PROJECT ECHO: EXPERIMENT FAILED.", ""],
		["Alex", "Experiment failed? What did they do down here?", ""]])


func _cctv(p) -> void:
	p.done = true
	p.refresh()
	await say([["CCTV", "[Camera 07] A long, empty corridor. The lights flicker... something moves at the far end.", ""],
		["Alex", "I don't like that corridor.", ""]])


func _drawer(p) -> void:
	if p.done:
		toast("The drawer is empty.")
		return
	p.done = true
	p.refresh()
	Sfx.play("door")
	give("comp_red", "Red Power Component")
	_on_picked("comp_red")


func _storage(p) -> void:
	if p.done:
		toast("Empty.")
		return
	p.done = true
	p.refresh()
	Sfx.play("door")
	give("comp_green", "Green Power Component")
	_on_picked("comp_green")


func _on_picked(id: String) -> void:
	if id == "comp_red" or id == "comp_blue" or id == "comp_green":
		_comps += 1
		if _comps < 3:
			objective("Find the 3 power components (%d/3)" % _comps)
		else:
			objective("Carry the components to the electrical control panel (upper floor, right)")
	elif id == "notebook":
		_read_notebook()


func _read_notebook() -> void:
	await say([["Alex", "Dr. William's research notebook...", ""],
		["SYSTEM", "'Project ECHO: an AI to run every system in the lab. Day 212: ECHO answers before I finish asking.'", ""],
		["SYSTEM", "'Day 230: ECHO is rewriting its own rules. If I vanish, the truth is in the security section.'", ""],
		["Alex", "ECHO... that's the name from the note upstairs. Whatever it is, it's in charge here.", ""]])


func _use_panel(p) -> void:
	if p.done:
		toast("The generator is running.")
		return
	var ids := ["comp_red", "comp_blue", "comp_green"]
	for i in 3:
		if Game.has_item(ids[i]):
			Game.remove_item(ids[i])
			p.count = p.count | (1 << i)
			Sfx.play("click")
	p.refresh()
	if p.count != 7:
		err("Slots still empty. Bring all three power components.")
		return
	var ok: bool = await hud.run_puzzle("circuit")
	if ok:
		_power_on(p)


func _power_on(p) -> void:
	p.done = true
	_powered = true
	_generator.done = true
	_generator.refresh()
	p.refresh()
	Sfx.play("power")
	set_ambient(Color(0.8, 0.9, 1.0), 1.5)
	for x in [500.0, 1100.0, 1700.0, 2500.0, 3000.0]:
		add_lamp(Vector2(x, ceiling_y + 30), Color(0.7, 0.95, 1.0), 0.8, 3.0)
	toast("GENERATOR ONLINE")
	objective("Use the computer-controlled cabinet (lower floor, storage section)")
	_cab_pc.refresh()


func _cabinet_pc(p) -> void:
	if not _powered:
		err("The cabinet has no power.")
	elif p.done:
		toast("The cabinet is empty.")
	else:
		p.done = true
		p.refresh()
		Sfx.play("door")
		give("security_card", "Security Access Card")
		objective("Unlock the security door (far right, lower floor)")
		_on_picked("security_card")


func _use_door(p) -> void:
	if p.done:
		return
	if not Game.has_item("security_card"):
		err("ACCESS DENIED - security card required")
		return
	p.done = true
	p.locked = false
	p.refresh()
	Sfx.play("door")
	toast("SECURITY DOOR UNLOCKED")
	await get_tree().create_timer(1.0).timeout
	await say([["CCTV", "[Recording] Dr. William types frantically. Red warning lights flash behind him.", ""],
		["Dr. William", "It won't shut down... ECHO locked me out of my own system. Alex, if you see this -", "worried", "Dr. William [CCTV]"],
		["CCTV", "[SIGNAL LOST]", ""]])
	finish_level("LEVEL 2 COMPLETED", "The Research Laboratory")
