extends Node2D
## Shared level logic. Level scripts extend this and override _setup(), _build(), _start().

const PropScript := preload("res://scripts/prop.gd")
const BackgroundScript := preload("res://scripts/lab_background.gd")
const CameraScript := preload("res://scripts/sec_camera.gd")
const PlayerScene := preload("res://scenes/player.tscn")
const HudScene := preload("res://scenes/hud.tscn")

var level_number: int = 1
var width: float = 3000.0
var floor_y: float = 560.0
var ceiling_y: float = 80.0
var variant: int = 0
var ambient: Color = Color(0.35, 0.38, 0.55)
var bg_signs: Array = []
var mid_floor: Array = []   # [y, x0, x1] visual second storey
var spawn_point: Vector2 = Vector2(150, 532)
var checkpoint: Vector2 = Vector2(150, 532)
var world: Node2D
var player = null
var hud = null
var canvas_mod: CanvasModulate
var covers: Array = []
var cams: Array = []
var _lamps: Array = []
var _finished: bool = false
var _alert_cd: float = 0.0
var _time: float = 0.0


func _setup() -> void:
	pass


func _build() -> void:
	pass


func _start() -> void:
	pass


func _ready() -> void:
	world = Node2D.new()
	add_child(world)
	canvas_mod = CanvasModulate.new()
	add_child(canvas_mod)
	_setup()
	Game.current_level = level_number
	canvas_mod.color = ambient
	var bg = BackgroundScript.new()
	bg.w = width
	bg.floor_y = floor_y
	bg.ceiling_y = ceiling_y
	bg.variant = variant
	bg.signs = bg_signs
	if not mid_floor.is_empty():
		bg.mid_floor_y = mid_floor[0]
		bg.mid_x0 = mid_floor[1]
		bg.mid_x1 = mid_floor[2]
	world.add_child(bg)
	add_block(Rect2(0, floor_y, width, 200), Color(0, 0, 0, 0), 1, false)
	add_block(Rect2(-60, -400, 60, 1600), Color(0, 0, 0, 0), 1, false)
	add_block(Rect2(width, -400, 60, 1600), Color(0, 0, 0, 0), 1, false)
	add_block(Rect2(0, ceiling_y - 60, width, 60), Color(0, 0, 0, 0), 1, false)
	_build()
	player = PlayerScene.instantiate()
	player.position = spawn_point
	add_child(player)
	player.set_limits(0, int(ceiling_y) - 20, int(width), int(floor_y) + 80)
	hud = HudScene.instantiate()
	add_child(hud)
	hud.bind(player, self)
	Sfx.start_music()
	_start()


func _process(delta: float) -> void:
	_time += delta
	_alert_cd = maxf(0.0, _alert_cd - delta)
	for l in _lamps:
		l.energy = l.get_meta("base") * (0.8 + 0.2 * sin(_time * 13.0 + l.position.x) * sin(_time * 5.0))


# ------------------------------------------------------------------ builders
func add_block(rect: Rect2, col: Color = Color("3b4366"), layer: int = 1, vis: bool = true, one_way: bool = false) -> StaticBody2D:
	var b := StaticBody2D.new()
	b.collision_layer = layer
	b.collision_mask = 0
	b.position = rect.position
	var cs := CollisionShape2D.new()
	var rs := RectangleShape2D.new()
	rs.size = rect.size
	cs.shape = rs
	cs.position = rect.size / 2.0
	cs.one_way_collision = one_way
	b.add_child(cs)
	if vis:
		var cr := ColorRect.new()
		cr.size = rect.size
		cr.color = col
		cr.mouse_filter = Control.MOUSE_FILTER_IGNORE
		b.add_child(cr)
		var edge := ColorRect.new()
		edge.size = Vector2(rect.size.x, 3)
		edge.color = Color("3fd8ff").darkened(0.2)
		edge.mouse_filter = Control.MOUSE_FILTER_IGNORE
		b.add_child(edge)
	world.add_child(b)
	return b


func add_platform(x: float, y: float, w: float) -> void:
	add_block(Rect2(x, y, w, 12), Color("39445a"), 2, true, true)


func add_ladder(x: float, platform_y: float, base_y: float = -1.0):
	var by := floor_y if base_y < 0.0 else base_y
	return make_prop("ladder", Vector2(x, by), Vector2(34, by - (platform_y - 12.0)), "", Callable(), false)


func make_prop(kind: String, pos: Vector2, sz: Vector2, prompt: String = "", cb: Callable = Callable(), interactive: bool = true, icon: String = ""):
	var p = PropScript.new()
	p.kind = kind
	p.position = pos
	p.size = sz
	p.prompt = prompt
	p.on_interact = cb
	p.interactive = interactive
	p.icon = icon
	world.add_child(p)
	return p


func deco(kind: String, x: float, y: float, w: float, h: float, tint: Color = Color("56607f")):
	var p = make_prop(kind, Vector2(x, y), Vector2(w, h), "", Callable(), false)
	p.tint = tint
	return p


func add_item(id: String, label: String, icon: String, pos: Vector2, hint: String = ""):
	var p = make_prop("item", pos, Vector2(28, 28), "Pick up " + label, Callable(), true, icon)
	p.on_interact = func(it): _pick(it, id, label)
	return p


func _pick(it, id: String, label: String) -> void:
	it.queue_free()
	give(id, label)
	_on_picked(id)


func _on_picked(_id: String) -> void:
	pass


func add_crate(cx: float, base_y: float, h: float = 50.0, w: float = 56.0, cover: bool = true) -> void:
	add_block(Rect2(cx - w / 2.0, base_y - h, w, h), Color(0, 0, 0, 0), 1, false)
	make_prop("crate", Vector2(cx, base_y), Vector2(w, h), "", Callable(), false)
	if cover:
		covers.append(Rect2(cx - w / 2.0 - 25.0, base_y - 100.0, w + 50.0, 100.0))


func add_lamp(pos: Vector2, col: Color, energy: float = 0.9, tscale: float = 2.4, flicker: bool = false):
	var l := PointLight2D.new()
	l.texture = Game.light_texture()
	l.position = pos
	l.color = col
	l.energy = energy
	l.texture_scale = tscale
	l.set_meta("base", energy)
	world.add_child(l)
	var fx := ColorRect.new()
	fx.size = Vector2(46, 6)
	fx.position = pos + Vector2(-23, -22)
	fx.color = col.lightened(0.3)
	fx.mouse_filter = Control.MOUSE_FILTER_IGNORE
	world.add_child(fx)
	if flicker:
		_lamps.append(l)
	return l


func add_camera(pos: Vector2, mount: float = 0.0, from_deg: float = 55.0, to_deg: float = 125.0, rng: float = 340.0, spd: float = 0.9):
	var c = CameraScript.new()
	c.position = pos
	c.level = self
	c.mount_len = mount
	c.sweep_from = from_deg
	c.sweep_to = to_deg
	c.range_len = rng
	c.speed = spd
	world.add_child(c)
	cams.append(c)
	return c


# ------------------------------------------------------------------ helpers
func say(lines: Array) -> void:
	await hud.say_lines(lines)


func toast(t: String) -> void:
	hud.toast(t)


func objective(t: String) -> void:
	hud.set_objective(t)


func ctl(desktop: String, touch: String) -> String:
	return touch if Game.touch_enabled else desktop


func give(id: String, label: String) -> void:
	Game.add_item(id, label)
	Sfx.play("pickup")
	toast("Picked up: " + label)


func err(msg: String) -> void:
	Sfx.play("error")
	toast(msg)


func set_ambient(c: Color, dur: float = 1.5) -> void:
	create_tween().tween_property(canvas_mod, "color", c, dur)


func player_hidden() -> bool:
	if not player.crouching:
		return false
	for r in covers:
		if r.has_point(player.global_position):
			return true
	return false


func camera_spotted() -> void:
	if _alert_cd > 0.0:
		return
	_alert_cd = 3.0
	Sfx.play("alarm")
	toast("SPOTTED BY SECURITY! Returning to checkpoint...")
	player.control_enabled = false
	await hud.fade_to(1.0, 0.3)
	player.teleport(checkpoint)
	await hud.fade_to(0.0, 0.3)
	if not hud.dialog_active:
		player.control_enabled = true


func finish_level(title: String, sub: String) -> void:
	if _finished:
		return
	_finished = true
	player.control_enabled = false
	Game.mark_complete(level_number)
	Sfx.play("win")
	await hud.show_complete(title, sub, level_number)
