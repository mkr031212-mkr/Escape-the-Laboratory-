extends "res://scripts/level_base.gd"
## LEVEL 4 - THE FORGOTTEN ARCHIVE

const UP := 330.0
const PASSWORD := "0712"
var _files: int = 0
var _scanned: bool = false
var _cell_in: bool = false
var _pass_ok: bool = false
var _doc_read: bool = false
var _office
var _shelf
var _elevator


func _setup() -> void:
	level_number = 4
	width = 3300.0
	variant = 3
	ambient = Color(0.20, 0.25, 0.36)
	bg_signs = [[1100.0, "CONFIDENTIAL RECORDS"], [2150.0, "SCAN & DIGITIZE"], [450.0, "WILLIAM'S RESEARCH", 378.0], [1300.0, "MYSTERY DETAILS", 378.0], [2900.0, "HIDDEN PASSAGE", 378.0]]
	spawn_point = Vector2(110, floor_y - 28.0)
	checkpoint = spawn_point


func _build() -> void:
	add_platform(100, UP, 2700)
	add_ladder(150, UP)
	add_ladder(1450, UP)
	add_ladder(2780, UP)
	# ---- upper floor: records
	deco("shelf", 330, UP, 120, 150, Color("46506f"))
	deco("desk", 620, UP, 170, 56, Color("5f7088"))
	add_item("file1", "Research File 01", "file", Vector2(620, UP - 56))
	deco("locker", 880, UP, 90, 130, Color("6a7690"))
	var fc = make_prop("locker", Vector2(1010, UP), Vector2(90, 130), "Search filing cabinet", Callable(), true)
	fc.tint = Color("6a7690")
	fc.on_interact = func(p): _filing(p)
	deco("locker", 1130, UP, 90, 130, Color("6a7690"))
	var rc = make_prop("cabinet", Vector2(1750, UP), Vector2(100, 150), "Restricted storage cabinet", Callable(), true)
	rc.on_interact = func(p): _restricted(p)
	var sc = make_prop("desk", Vector2(2150, UP), Vector2(160, 46), "Scanner", Callable(), true)
	sc.tint = Color("4f7a8a")
	sc.on_interact = func(p): _scanner(p)
	deco("desk", 2500, UP, 120, 50, Color("5f7088"))
	var cp = make_prop("computer", Vector2(2500, UP - 50), Vector2(66, 66), "Archive computer", Callable(), true)
	cp.tint = Color("7df9ff")
	cp.text = "ARCHIVE"
	cp.on_interact = func(p): _computer(p)
	# ---- lower floor: William's research, mystery details, passage
	var dr = make_prop("drawer", Vector2(300, floor_y), Vector2(110, 70), "Search desk drawer", Callable(), true)
	dr.on_interact = func(p): _desk(p)
	deco("chair", 210, floor_y, 40, 50, Color("2f58a8"))
	var ph = make_prop("photo", Vector2(520, floor_y - 120), Vector2(40, 50), "Look at photo", Callable(), true)
	ph.on_interact = func(_p): say([["Alex", "Dr. William... He looks kind. Why do I feel like I know him?", ""]])
	add_item("note", "Password Note", "note", Vector2(620, floor_y))
	deco("board", 780, floor_y - 120, 110, 80)
	var mf = make_prop("board", Vector2(1150, floor_y - 120), Vector2(110, 80), "Read folder: SUBJECT ALEX", Callable(), true)
	mf.on_interact = func(_p): say([["SYSTEM", "A dusty folder marked SUBJECT ALEX is locked inside a case. Maybe the archive computer can open it.", ""]])
	add_item("cell", "Power Component", "cell", Vector2(1400, floor_y))
	deco("desk", 1700, floor_y, 130, 50, Color("5f7088"))
	_office = make_prop("door", Vector2(2300, floor_y), Vector2(80, 130), "Dr. William's private office", Callable(), true, "OFFICE")
	_office.tint = Color("4a5368")
	_office.on_interact = func(p): _use_office(p)
	_elevator = make_prop("door", Vector2(2950, floor_y), Vector2(90, 140), "Use elevator", Callable(), true, "ELEVATOR")
	_elevator.tint = Color("5a6378")
	_elevator.enabled = false
	_elevator.on_interact = func(p): _use_elevator(p)
	_shelf = make_prop("bookshelf", Vector2(2950, floor_y), Vector2(120, 170), "Pull bookshelf", Callable(), true)
	_shelf.on_interact = func(p): _use_shelf(p)
	for x in [300.0, 1100.0, 1900.0, 2700.0]:
		add_lamp(Vector2(x, ceiling_y + 30), Color(0.5, 0.75, 1.0), 0.5, 2.2, true)


func _start() -> void:
	objective("Find three missing research files (0/3)")
	await say([["ECHO", "You shouldn't have come this far, Alex.", ""],
		["Alex", "Who are you? And why do you know my name?", ""],
		["ECHO", "Some answers are better left undiscovered.", ""]])
	toast("The metal door closes behind you.")


func _on_picked(id: String) -> void:
	if id == "file1" or id == "file2" or id == "file3":
		_files += 1
		if _files < 3:
			objective("Find three missing research files (%d/3)" % _files)
		else:
			objective("Digitize the research files at the scanner")


func _filing(p) -> void:
	if p.done:
		toast("Only old papers left.")
		return
	p.done = true
	p.refresh()
	Sfx.play("door")
	give("file2", "Research File 02")
	_on_picked("file2")


func _desk(p) -> void:
	if p.done:
		toast("The drawer is empty.")
		return
	p.done = true
	p.refresh()
	Sfx.play("door")
	give("cab_key", "Cabinet Key")


func _restricted(p) -> void:
	if p.done:
		toast("Empty.")
		return
	if not Game.has_item("cab_key"):
		err("LOCKED. Look for a key in Dr. William's research section.")
		return
	p.done = true
	p.refresh()
	Game.remove_item("cab_key")
	Sfx.play("door")
	give("file3", "Research File 03")
	_on_picked("file3")


func _scanner(_p) -> void:
	if _scanned:
		toast("Files already digitized.")
		return
	if not (Game.has_item("file1") and Game.has_item("file2") and Game.has_item("file3")):
		err("The scanner needs all three research files.")
		return
	Game.remove_item("file1")
	Game.remove_item("file2")
	Game.remove_item("file3")
	_scanned = true
	Sfx.play("power")
	toast("FILES DIGITIZED")
	objective("Restore the archive computer (needs a power component and a password)")


func _computer(p) -> void:
	if p.done:
		return
	if not _cell_in:
		if not Game.has_item("cell"):
			err("The computer is dead. A power component is missing.")
			return
		Game.remove_item("cell")
		_cell_in = true
		Sfx.play("power")
		toast("Power component installed")
	if not _pass_ok:
		if not Game.has_item("note"):
			err("PASSWORD REQUIRED. Check Dr. William's research section.")
			return
		var ok: bool = await hud.run_puzzle("keypad", PASSWORD)
		if not ok:
			return
		_pass_ok = true
		set_ambient(Color(0.6, 0.75, 0.95), 1.5)
		toast("ARCHIVE COMPUTER ONLINE")
	if not _scanned:
		toast("Digitize the three research files at the scanner first.")
		return
	p.done = true
	await say([["SYSTEM", "SUBJECT NAME: ALEX.", ""], ["SYSTEM", "PROJECT: MEMORY RESTORATION.", ""],
		["SYSTEM", "STATUS: EXPERIMENT COMPLETED.", ""],
		["Alex", "What? Why is my name here?", ""],
		["ECHO", "STOP! You are accessing restricted information.", ""]])
	Sfx.play("zap")
	toast("THE COMPUTER SHUTS DOWN")
	_doc_read = true
	_office.locked = false
	_office.refresh()
	objective("Dr. William's private office is unlocked (lower floor)")


func _use_office(p) -> void:
	if p.locked:
		err("The office is locked.")
	elif p.done:
		toast("Nothing else here.")
	else:
		p.done = true
		p.refresh()
		Sfx.play("door")
		give("idcard", "Dr. William's ID Card")
		objective("Find the hidden passage behind the bookshelf")


func _use_shelf(p) -> void:
	if not _doc_read:
		toast("Just a heavy bookshelf.")
		return
	Sfx.play("door")
	toast("HIDDEN ELEVATOR FOUND")
	_elevator.enabled = true
	p.queue_free()


func _use_elevator(p) -> void:
	if not Game.has_item("idcard"):
		err("ID CARD REQUIRED")
		return
	Sfx.play("door")
	p.done = true
	p.locked = false
	p.refresh()
	await get_tree().create_timer(0.8).timeout
	await hud.fade_to(1.0, 1.0)
	await say([["SYSTEM", "WELCOME TO THE EXPERIMENT CHAMBER.", ""]])
	finish_level("LEVEL 4 COMPLETED", "The Forgotten Archive")
