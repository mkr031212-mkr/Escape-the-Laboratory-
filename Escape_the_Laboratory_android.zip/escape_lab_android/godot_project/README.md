# Escape the Laboratory (Godot 4.2+ project)

2D puzzle / adventure / mystery for Android and desktop. Chapter 1 (levels 1-3) and Chapter 2 "The Hidden Truth" (levels 4-7).
Open `project.godot` in Godot 4.2+ (GL Compatibility renderer) and press F5.

## Structure
- `project.godot` - project file (main scene, autoloads, 1280x720 landscape, stretch expand)
- `scenes/` - main_menu, level_1..3, player, hud
- `scripts/` - game.gd (state/input), sfx.gd (generated audio), player.gd, level_base.gd, level_1..3.gd,
  prop.gd (objects/items/doors), hud.gd, puzzle_ui.gd (circuit, keypad, memory puzzles), touch_controls.gd,
  sec_camera.gd, lab_background.gd, main_menu.gd
- `assets/` - sprites (Alex cut-outs from your pose pictures), portraits (Dr. William expressions, Alex face), concept (level art for level select)

## Controls
A/D or arrows walk | Shift run | Space jump | S crouch | W/S ladders | E interact | F flashlight | Esc pause.
Touch buttons appear automatically on phones (multi-touch).

## Levels
1. The Awakening - silver key (desk drawer) -> storage cabinet -> blue access card; password note on notice board -> computer -> electronic lock -> blue lab door.
2. The Research Laboratory - red / blue / green power components -> electrical panel (circuit puzzle) -> generator; Dr. William's notebook; security card from computer cabinet -> security door.
3. The Security Room - password clue -> security computer -> server key -> fuse -> backup generator + switch -> ECHO terminal puzzle -> final exit card -> exit.
4. The Forgotten Archive - 3 research files, scanner, archive computer (power part + password), SUBJECT ALEX, William's office, hidden elevator.
5. The Experiment Chamber - 3 power cells -> generator, 3 machine components -> control panel (sequence puzzle), observation room, ECHO data chip.
6. ECHO's Core - backup power parts -> generator, computer connection puzzle -> memory database, hidden video -> restore recording, elevator.
7. The Final Truth - confidential cabinet (code), restore the experiment video, then choose: preserve or shut down ECHO. Two endings, then the "backup system activated" teaser.
Dr. William never appears physically; he speaks through recordings and CCTV.

## Android export
Project > Install Android Build Template, install Android SDK/JDK, then Project > Export > Android (APK/AAB).
(No .exe is included - this is a Godot project, not a Windows build.)
