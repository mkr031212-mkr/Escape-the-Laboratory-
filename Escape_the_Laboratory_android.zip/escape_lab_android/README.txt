ESCAPE THE LABORATORY - Android project (Kotlin + Godot game)
==============================================================

Layout
  settings.gradle, build.gradle, gradle.properties   Gradle project files
  app/build.gradle                                    Android app module (com.escapelab.game)
  app/src/main/AndroidManifest.xml                    Landscape, full-screen app
  app/src/main/java/com/escapelab/game/MainActivity.kt   Main app code: runs the game full screen, offline
  app/src/main/assets/www/                            Game files (created by the build)
  godot_project/                                      The full Godot 4.3 game (7 levels) - open project.godot
  .github/workflows/build.yml                         GitHub build that creates the APK

How to get the APK (easiest - no software needed)
  1. Create a GitHub repository and upload everything in this folder.
  2. Open the Actions tab -> "Build Android APK" -> Run workflow (it also runs on every push).
  3. When it finishes, open the run and download the artifact "EscapeTheLaboratory-apk"
     (app-debug.apk). Copy it to your phone and install it.

Build on your own computer
  1. Install Godot 4.3 and its export templates.
  2. Open godot_project/project.godot -> Project > Export > preset "Web" -> Export
     (it writes to app/src/main/assets/www/index.html).
  3. Open this folder in Android Studio and press Run, or run:  gradle assembleDebug

Notes
  - The game runs as a Godot Web export inside a WebView, fully offline.
  - Progress is saved inside the app. Controls: on-screen touch buttons.
  - This project was written without being able to run Godot or Gradle here, so the first build
    is the real test. If the GitHub build fails, send the error text from the failed step.
